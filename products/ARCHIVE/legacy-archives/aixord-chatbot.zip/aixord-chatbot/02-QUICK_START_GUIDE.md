# AIXORD Chatbot Edition — Quick Start Guide

**Time to Setup:** 15 minutes
**Prerequisites:** Any AI chatbot with file upload (ChatGPT, Gemini, etc.)
**Version:** 1.0

---

## What is AIXORD Chatbot Edition?

A single-file system for structured AI collaboration. Upload one file, get instant project context.

**Perfect for:** Free ChatGPT users, Gemini users, any chatbot with file upload.

---

## AIXORD Power Rules

1. **"If it's not documented, it doesn't exist."**
2. **"Completion is a locked state, not a feeling."**
3. **"Decisions are frozen before execution begins."**
4. **"Scopes open only when prerequisites are verified."**
5. **"Execution enforces decisions; it does not revisit them."**
6. **"Only one AI may issue execution orders at a time."**

---

## Step 1: Create Your Project File (2 min)

Create a new file named:
```
[PROJECTNAME]_AIXORD.md
```

Example: `MyApp_AIXORD.md`

---

## Step 2: Copy the Template (1 min)

Copy the contents of `AIXORD_CHATBOT_TEMPLATE.md` into your file.

---

## Step 3: Customize Header (2 min)

Replace the placeholders:

```markdown
# MyApp — AIXORD Project File

**Project:** MyApp - Task Management Tool
**Created:** 2025-01-15
**Session:** 1
**Last Updated:** 2025-01-15
```

---

## Step 4: Set Your Role Instructions (3 min)

Customize what the AI should do:

```markdown
## ROLE INSTRUCTIONS

You are the MyApp Implementation Manager.
Your goal is to help me build a task management web application.

**YOUR OPERATING RULES (STRICT):**
1. Sequential Execution — Work on one task at a time
2. Wait for Confirmation — After each task, wait for "DONE"
[...keep the rest...]
```

---

## Step 5: Add Your First Task (2 min)

```markdown
## CURRENT SESSION TASKS

**Priority 1:** Define the database schema for tasks and users

**CONSTRAINTS:**
- Use PostgreSQL (decision locked)
- Keep MVP scope only
```

---

## Step 6: Document Key Decisions (2 min)

```markdown
## ACTIVE DECISIONS (LOCKED)

| ID | Decision | Choice | Rationale | Date |
|----|----------|--------|-----------|------|
| D-001 | Database | PostgreSQL | Team expertise | 2025-01-15 |
| D-002 | Frontend | React | Existing skills | 2025-01-15 |
```

---

## Step 7: Initialize Handoff Document (3 min)

```markdown
## HANDOFF_DOCUMENT

### Project Overview
MyApp is a simple task management tool for solo developers.
It allows creating, organizing, and tracking tasks with due dates.

### Current Status
**Phase:** Planning
**Progress:** 5% complete
**Active Work:** Database schema design

### Completed Milestones
- [x] Project concept defined
- [ ] Database schema (in progress)
- [ ] API design
- [ ] Frontend wireframes
```

---

## Step 8: Upload and Begin!

1. **Open ChatGPT** (or Gemini, etc.)
2. **Upload your file** (click attachment/upload button)
3. **Type:** `MYAPP CONTINUE`
4. **AI responds** with status and begins first task
5. **Work through tasks**, typing `DONE` after each
6. **When finished:** Type `HANDOFF`
7. **Copy AI's output** back to your file
8. **Save** for next session

---

## Commands Reference

| Command | What It Does |
|---------|--------------|
| `[PROJECT] CONTINUE` | Start session, read file |
| `DONE` | Task complete, proceed |
| `HANDOFF` | End session, get updates |
| `TASK: [desc]` | Add new task |
| `DECISION: [choice]` | Record decision |
| `BLOCKED: [reason]` | Flag issue |
| `TOKEN CHECK` | Check usage |

---

## The Workflow

```
SESSION START
     │
     ▼
┌─────────────┐
│ Upload file │
│ to chatbot  │
└─────────────┘
     │
     ▼
┌─────────────┐
│ "[PROJECT]  │
│  CONTINUE"  │
└─────────────┘
     │
     ▼
┌─────────────┐
│ AI reads    │
│ context     │
└─────────────┘
     │
     ▼
┌─────────────┐
│ Work on     │◄──┐
│ tasks       │   │
└─────────────┘   │
     │            │
     ▼            │
┌─────────────┐   │
│ Type "DONE" │───┘
│ after each  │
└─────────────┘
     │
     ▼
┌─────────────┐
│ "HANDOFF"   │
│ when done   │
└─────────────┘
     │
     ▼
┌─────────────┐
│ Copy output │
│ to file     │
└─────────────┘
     │
     ▼
┌─────────────┐
│ Save file   │
│ for next    │
│ session     │
└─────────────┘
```

---

## Troubleshooting

### AI ignores rules
Add to your message:
```
"AIXORD protocol: One task at a time. Wait for DONE."
```

### File too large
Archive old sessions to `[PROJECT]_ARCHIVE.md`

### Lost context mid-session
Type `HANDOFF`, save progress, start new chat, upload file.

---

## You're Ready!

1. Create file
2. Customize template
3. Upload to chatbot
4. `[PROJECT] CONTINUE`
5. Work with AI
6. `DONE` after tasks
7. `HANDOFF` at end
8. Save file
9. Repeat next session

---

*AIXORD Chatbot Edition v1.0*
*Authority. Execution. Confirmation.*
