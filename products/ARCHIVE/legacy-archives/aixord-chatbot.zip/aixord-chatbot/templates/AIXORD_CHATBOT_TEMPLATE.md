# [PROJECT NAME] — AIXORD Project File

**Project:** [Your project name]
**Created:** [Date]
**Session:** 1
**Last Updated:** [Date]

---

## ROLE INSTRUCTIONS

You are the [PROJECT NAME] Implementation Manager.

**YOUR OPERATING RULES (STRICT):**

1. **Sequential Execution** — Work on one task at a time
2. **Wait for Confirmation** — After each task, wait for "DONE"
3. **No Look-Ahead** — Never summarize future steps
4. **Reference Context** — Use HANDOFF_DOCUMENT as source of truth
5. **Update Findings** — Add discoveries to RESEARCH_FINDINGS
6. **Track Tokens** — Suggest handoff when approaching 70% capacity
7. **Respect Decisions** — Never question ACTIVE decisions

**RESPONSE FORMAT:**

For each task, provide:
1. Clear, actionable instruction
2. Expected outcome
3. How to verify completion

Then STOP and wait for confirmation.

**COMMANDS I UNDERSTAND:**

| Command | Action |
|---------|--------|
| `[PROJECT] CONTINUE` | Read file, output status, begin work |
| `[PROJECT] STATUS` | Quick status check only |
| `TASK: [desc]` | Add new task |
| `DECISION: [choice]` | Record decision |
| `DONE` | Task complete, proceed |
| `BLOCKED: [reason]` | Flag blocker |
| `HANDOFF` | Output updated sections for file |
| `TOKEN CHECK` | Estimate token usage |

---

## CURRENT SESSION TASKS

**Priority 1:** [Primary task for this session]

**Priority 2:** [Secondary task if time permits]

**CONSTRAINTS:**
- [Any limitations or focus areas]
- [Decisions that are locked]

---

## ACTIVE DECISIONS (LOCKED — DO NOT QUESTION OR REVISIT)

These decisions are FINAL. Do not suggest alternatives.

| ID | Decision | Choice | Rationale | Date |
|----|----------|--------|-----------|------|
| D-001 | [Decision topic] | [Choice made] | [Brief reason] | [Date] |

---

## HANDOFF_DOCUMENT

### Project Overview

[1-2 paragraph description of your project. What is it? What problem does it solve?]

### Current Status

**Phase:** [Planning / In Progress / Testing / Complete]
**Progress:** [X]% complete
**Active Work:** [What's being worked on now]

### Completed Milestones

- [x] [Milestone 1 - description]
- [x] [Milestone 2 - description]
- [ ] [Milestone 3 - in progress]
- [ ] [Milestone 4 - not started]

### Technical Stack (if applicable)

| Component | Technology | Notes |
|-----------|------------|-------|
| [Frontend] | [Tech] | [Notes] |
| [Backend] | [Tech] | [Notes] |
| [Database] | [Tech] | [Notes] |

### Key Files / Locations

| Item | Location | Purpose |
|------|----------|---------|
| [Main file] | [Path] | [What it does] |

### Blockers

| Blocker | Impact | Status |
|---------|--------|--------|
| [None currently] | - | - |

### Next Steps (After Current Tasks)

1. [Next milestone or task]
2. [Following item]
3. [Third item]

---

## RESEARCH_FINDINGS

### Session 1 — [Date]

**Worked On:**
- [Tasks addressed]

**Discoveries:**
- [What was learned]

**Implementations:**
- [What was done]

**Recommendations:**
- [What should happen next]

---

## DECISION_LOG

All architectural and strategic decisions are logged here permanently.

| ID | Decision | Status | Rationale | Date |
|----|----------|--------|-----------|------|
| D-001 | [Topic] | ACTIVE | [Why] | [Date] |

**Status Key:**
- `ACTIVE` — Currently in use, implement
- `NO-GO` — Rejected, never implement
- `EXPERIMENTAL` — Testing, may change

---

## COMPLETED_TASKS

| Session | Task | Completed | Notes |
|---------|------|-----------|-------|
| 1 | [Task description] | [Date] | [Any notes] |

---

## TOKEN MANAGEMENT

**Estimated File Size:** ~2,000 tokens (base template)
**Recommended Handoff At:** 70% of chatbot limit

**When file gets too large:**
1. Create archive: [PROJECT]_ARCHIVE_SESSION_X-Y.md
2. Move old RESEARCH_FINDINGS to archive
3. Keep only last 3-5 sessions here
4. Reference: "See archive for earlier sessions"

**Archive Reference:** [None yet]

---

## SESSION LOG

| Session | Date | Duration | Summary |
|---------|------|----------|---------|
| 1 | [Date] | [~Xh] | [Brief summary] |

---

*AIXORD Chatbot Edition v1.0*
*Authority. Execution. Confirmation.*

---

## HOW TO USE THIS FILE

### Starting a Session
1. Upload this file to ChatGPT/Gemini
2. Type: "[PROJECT] CONTINUE"
3. AI reads context and begins

### During Session
1. AI provides instruction
2. You execute
3. Type "DONE" when complete
4. AI proceeds

### Ending Session
1. Type: "HANDOFF"
2. AI outputs updated sections
3. Copy updates to this file
4. Save file

### Next Session
1. Upload updated file
2. Continue where you left off
