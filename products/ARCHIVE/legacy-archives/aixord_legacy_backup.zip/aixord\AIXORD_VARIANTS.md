# AIXORD Product Variants

**Version:** 1.0
**Created:** December 25, 2025
**Source:** Chat histories (ChatGPT brainstorm) + Claude Code suggestions

---

## Overview

AIXORD (AI Execution Order Framework) can be adapted into multiple product variants to serve different audiences, platforms, and use cases.

---

## DISCUSSED VARIANTS (From Brainstorm Sessions)

These variants were discussed in previous ChatGPT brainstorming sessions:

### 1. AIXORD: AI Execution Order Framework (Main Product)

| Attribute | Value |
|-----------|-------|
| **Status** | v1.1 Complete |
| **Target** | Claude Code Pro users |
| **Requirements** | Claude Pro subscription, folder/file access |
| **Format** | Full methodology book + 8 templates |
| **Price** | $9.99 (KDP) + $29 (Gumroad templates) |
| **Platform** | Amazon KDP, Gumroad |

**Key Features:**
- Three-Way Team Structure (Architect/Director/Commander)
- Role Transition Rule (Brainstorming → Execution)
- Scope Locking & Dependency Management
- AIXORD Power Rules (6 memorizable rules)
- Complete template package

---

### 2. AIXORD Chatbot Edition

| Attribute | Value |
|-----------|-------|
| **Status** | Conceptual |
| **Target** | ChatGPT/Gemini FREE users, simple chatbot interfaces |
| **Requirements** | File upload capability only (no folder access) |
| **Format** | Single-file template system |
| **Price** | $4.99-$7.99 |
| **Platform** | Amazon KDP, Gumroad |

**Key Differences from Main:**
- All context in ONE uploadable file
- Token-aware handoff tracking (AI monitors token usage)
- No folder structure needed
- Simpler keyword commands
- Top section (dynamic) + Bottom section (cumulative) architecture
- AI generates handoff when approaching token limits

**Architecture:**
```
┌─────────────────────────────────────────────────┐
│  TOP SECTION (Dynamic)                          │
│  • Role instructions                            │
│  • Current session tasks                        │
│  • Architectural decisions                      │
│  ↓ Updates flow downward ↓                      │
├─────────────────────────────────────────────────┤
│  BOTTOM SECTION (Cumulative)                    │
│  • HANDOFF_DOCUMENT (evolves)                   │
│  • RESEARCH_FINDINGS (grows)                    │
│  • Completed decisions & artifacts              │
└─────────────────────────────────────────────────┘
```

---

### 3. VA-AIXORD: Visual Audit Playbook

| Attribute | Value |
|-----------|-------|
| **Status** | Conceptual |
| **Target** | QA teams, platform owners, compliance auditors |
| **Requirements** | Any AI with image upload capability |
| **Format** | Methodology book + audit templates |
| **Price** | $9.99 |
| **Platform** | Amazon KDP |

**Origin:** Developed from K-12 platform walkthrough that identified 17+ gaps

**Key Features:**
- Scenario-Driven Visual Gap Audit (SVGA)
- Persona-based screenshot audits
- Gap classification system (UI/UX, Security, Compliance, Data, Flow)
- Severity scale (Critical, High, Medium, Low)
- Visual evidence rules
- Live gap ledger

**Workflow:**
```
1. Define Audit Envelope (persona, goal, compliance lens)
2. Step-by-step visual walkthrough
3. Screenshot evidence at each gate
4. Real-time gap logging
5. Gap-to-backlog translation
```

**Use Cases:**
- Platform audits (user registration flows)
- Security walkthroughs (session persistence, autofill leaks)
- Compliance audits (COPPA, FERPA, SOC2)
- Role switching verification
- Data deletion/RTBF flows

---

### 4. SEC-AIXORD: Security Audit Edition

| Attribute | Value |
|-----------|-------|
| **Status** | Conceptual |
| **Target** | Security teams, penetration testers |
| **Requirements** | AI with file/image upload |
| **Format** | Security-focused audit methodology |
| **Price** | $14.99 |
| **Platform** | Amazon KDP |

**Key Features:**
- Security-specific gap classification
- Session persistence audits
- Authentication flow verification
- Permission boundary testing
- Escalation trigger detection

---

### 5. K12-AIXORD: Education Compliance Edition

| Attribute | Value |
|-----------|-------|
| **Status** | Conceptual |
| **Target** | EdTech platforms, schools |
| **Requirements** | AI with file/image upload |
| **Format** | COPPA/FERPA compliance audit methodology |
| **Price** | $14.99 |
| **Platform** | Amazon KDP |

**Key Features:**
- Age verification flow audits
- Parental consent verification
- Minor data protection checks
- Age-appropriate UI verification
- FERPA compliance gates

---

## SUGGESTED VARIANTS (New Ideas)

These are additional variant possibilities:

### 6. Format Variants

| Variant | Description | Price |
|---------|-------------|-------|
| **AIXORD Kindle Edition** | eBook only (no templates) | $4.99 |
| **AIXORD Audiobook** | Audio version for commuters | $9.99 |
| **AIXORD Quick Reference** | Cheat sheet / poster | $2.99 |
| **AIXORD Video Course** | Screen recordings + walkthroughs | $49-$99 |

---

### 7. Audience Variants

| Variant | Target | Key Differences |
|---------|--------|-----------------|
| **AIXORD for Teams** | 2-5 developer teams | Multi-person workflows, shared scopes |
| **AIXORD Solo** | Solo developers | Simplified, single-person focus |
| **AIXORD for Beginners** | Non-technical users | Plain language, more hand-holding |
| **AIXORD Enterprise** | Large organizations | Governance, compliance, audit trails |

---

### 8. Platform Variants

| Variant | Platform | Key Differences |
|---------|----------|-----------------|
| **AIXORD for Claude** | Claude Code + Claude Web | Main product (current) |
| **AIXORD for ChatGPT** | ChatGPT (free/Pro) | Single-file, token tracking |
| **AIXORD for Gemini** | Google Gemini | Adapted commands, Google Docs integration |
| **AIXORD for Copilot** | GitHub Copilot | IDE-focused, code-centric |
| **AIXORD Universal** | Any AI | Platform-agnostic templates |

---

### 9. Industry Variants

| Variant | Industry | Key Differences |
|---------|----------|-----------------|
| **AIXORD for Web Dev** | Web developers | Frontend/backend scopes, deployment gates |
| **AIXORD for Data Science** | Data scientists | Notebook workflows, model training gates |
| **AIXORD for DevOps** | DevOps engineers | CI/CD integration, infrastructure scopes |
| **AIXORD for Mobile** | Mobile developers | iOS/Android specific workflows |
| **AIXORD for AI/ML** | AI engineers | Model lifecycle, training checkpoints |

---

### 10. Depth Variants

| Variant | Depth | Price |
|---------|-------|-------|
| **AIXORD Essentials** | Core concepts only (20 pages) | $4.99 |
| **AIXORD Complete** | Full methodology (current) | $9.99 |
| **AIXORD Masterclass** | Advanced + case studies | $19.99 |
| **AIXORD + Coaching** | Book + 1-hour consultation | $99 |

---

### 11. Bundle Products

| Bundle | Contents | Price |
|--------|----------|-------|
| **AIXORD Starter Pack** | Book + Templates + Quick Reference | $19.99 |
| **AIXORD Pro Bundle** | All variants (Claude, ChatGPT, Gemini) | $29.99 |
| **AIXORD Complete Collection** | All products + future updates | $49.99 |
| **AIXORD Team License** | 5-seat license + team guide | $79 |

---

## Priority Matrix

### Immediate (Q1 2026)

| Priority | Variant | Rationale |
|----------|---------|-----------|
| 1 | AIXORD Main (v1.1) | Already complete, just republish |
| 2 | AIXORD Chatbot Edition | Expands market to free AI users |
| 3 | VA-AIXORD Visual Audit | Documented from real audit |

### Near-term (Q2 2026)

| Priority | Variant | Rationale |
|----------|---------|-----------|
| 4 | AIXORD for ChatGPT | Large user base |
| 5 | AIXORD Quick Reference | Low effort, cross-sell |
| 6 | AIXORD for Beginners | Broader market |

### Future

| Priority | Variant | Rationale |
|----------|---------|-----------|
| 7+ | Industry variants | Market research needed |
| 8+ | Video Course | Requires production effort |
| 9+ | Enterprise | Requires sales infrastructure |

---

## Shared Components (All Variants)

### 1. AIXORD Power Rules
```
1. "If it's not documented, it doesn't exist."
2. "Completion is a locked state, not a feeling."
3. "Decisions are frozen before execution begins."
4. "Scopes open only when prerequisites are verified."
5. "Execution enforces decisions; it does not revisit them."
6. "Only one AI may issue execution orders at a time."
```

### 2. Core Principles
- Authority (orders, not suggestions)
- Execution (sequential, confirmable)
- Confirmation (evidence before proceeding)

### 3. Role Transition
- Brainstorming phase: AI = Analyst/Architect
- Execution phase: AI = Commander

### 4. Branding
- Dark blue (#0A1628)
- PMERIT logo
- "Authority. Execution. Confirmation." tagline

---

## Development Notes

### AIXORD Chatbot Edition Requirements

Based on chat history, this variant must support:
- Single file upload (no folder access)
- Token tracking built into AI prompts
- Automatic handoff generation when tokens low
- Top/bottom section architecture
- Keyword triggers for workflows

### VA-AIXORD Requirements

Based on K-12 audit, this variant must include:
- Step template (Action, Expected, Evidence, Observed, Gaps)
- Gap classification taxonomy
- Severity scale with colors
- Visual evidence rules
- Gap ledger format

---

## Next Actions

- [ ] Complete AIXORD main product republish
- [ ] Draft AIXORD Chatbot Edition manuscript
- [ ] Draft VA-AIXORD Visual Audit manuscript
- [ ] Create AIXORD for ChatGPT adaptation
- [ ] Design Quick Reference card
- [ ] Research industry variant demand

---

*AIXORD Variants v1.0 — Expanding the Framework*
