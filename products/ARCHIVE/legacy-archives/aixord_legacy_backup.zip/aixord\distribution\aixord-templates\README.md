# AIXORD — Template Package

**Version:** 1.0 — AI Execution Order Framework
**Thank you for your purchase!**

---

## What is AIXORD?

AIXORD (AI Execution Order) is a structured methodology for AI-human collaboration inspired by military OPORD doctrine:

| Principle | Description |
|-----------|-------------|
| **Authority** | AI issues orders, not suggestions |
| **Execution** | Sequential, confirmable tasks |
| **Confirmation** | Evidence before proceeding |

**The human decides *what* should be done; the AI decides *how* it is executed.**

---

## AIXORD Power Rules (Memorize These)

1. **"If it's not documented, it doesn't exist."**
2. **"Completion is a locked state, not a feeling."**
3. **"Decisions are frozen before execution begins."**
4. **"Scopes open only when prerequisites are verified."**
5. **"Execution enforces decisions; it does not revisit them."**
6. **"Only one AI may issue execution orders at a time."**

---

## Quick Setup (30 minutes)

### Step 1: Create Directory Structure

In your project root, run:

**Mac/Linux:**
```bash
mkdir -p .claude/scopes
mkdir -p docs/aixord
mkdir -p docs/handoffs
mkdir -p docs/archive
```

**Windows (PowerShell):**
```powershell
New-Item -ItemType Directory -Force -Path ".claude\scopes"
New-Item -ItemType Directory -Force -Path "docs\aixord"
New-Item -ItemType Directory -Force -Path "docs\handoffs"
New-Item -ItemType Directory -Force -Path "docs\archive"
```

### Step 2: Copy Templates

Copy these files to your project:

| From This Package | To Your Project |
|-------------------|-----------------|
| `templates/CLAUDE.md` | `.claude/CLAUDE.md` |
| `templates/CLAUDE_WEB_SYNC.md` | `.claude/CLAUDE_WEB_SYNC.md` |
| `templates/SYSTEM_GUIDE.md` | `.claude/SYSTEM_GUIDE.md` |
| `templates/MASTER_SCOPE.md` | `.claude/scopes/MASTER_SCOPE.md` |
| `templates/SCOPE_TEMPLATE.md` | `.claude/scopes/` (copy as needed) |
| `templates/AIXORD_GOVERNANCE.md` | `docs/aixord/AIXORD_GOVERNANCE.md` |
| `templates/AIXORD_STATE.json` | `docs/aixord/AIXORD_STATE.json` |
| `templates/AIXORD_TRACKER.md` | `docs/aixord/AIXORD_TRACKER.md` |

### Step 3: Customize

1. Open `.claude/CLAUDE.md`
2. Replace `[PROJECT NAME]` with your project name
3. Replace `[PROJECT]` in commands with your prefix (e.g., `MYAPP`)

4. Open `.claude/scopes/MASTER_SCOPE.md`
5. Fill in your project details

### Step 4: Setup Claude Web (Architect AI)

1. Go to claude.ai (or ChatGPT)
2. Open your project
3. Click "Set project instructions"
4. Paste your project context (see CLAUDE_WEB_SYNC.md for template)

### Step 5: Commit & Test

```bash
git add .claude/ docs/
git commit -m "chore: Setup AIXORD framework"
```

Then start Claude Code and type:
```
[YOURPROJECT] CONTINUE
```

---

## The Role Transition

This is the key innovation of AIXORD:

```
Phase 1: BRAINSTORMING (AI = Analyst/Architect)
├── Research and exploration
├── Discuss options with you
└── Decisions approved by you

↓ ROLE TRANSITION (Explicit) ↓

Phase 2: EXECUTION (AI = Commander)
├── AI issues orders (not suggestions)
├── You execute one step at a time
├── Confirm with evidence
└── Decisions are FROZEN
```

**No more negotiating during execution. No more revisiting decisions mid-task.**

---

## Package Contents

```
aixord-templates/
├── README.md                      <- You are here
├── LICENSE.md                     <- Usage terms
└── templates/
    ├── CLAUDE.md                  <- Claude Code instructions (AIXORD)
    ├── CLAUDE_WEB_SYNC.md         <- Architect AI sync file
    ├── SYSTEM_GUIDE.md            <- Complete reference guide
    ├── MASTER_SCOPE.md            <- Project vision template
    ├── SCOPE_TEMPLATE.md          <- Per-feature scope template
    ├── AIXORD_GOVERNANCE.md       <- Workflow rules
    ├── AIXORD_STATE.json          <- State tracking
    ├── AIXORD_TRACKER.md          <- Task status
    └── .gitignore                 <- Recommended ignores
```

---

## Quick Reference

### Commands

| Command | Effect |
|---------|--------|
| `[PROJECT] CONTINUE` | Start session with full protocol |
| `AUDIT SCOPE: [name]` | Audit reality for a feature |
| `SCOPE UPDATED: [name]` | Implement after specs written |
| `SCOPE: [name]` | Load existing scope context |
| `UNLOCK: [file]` | Unlock file for modification |
| `RELOCK: [file]` | Re-lock file after changes |
| `DONE` | Confirm step complete |

### Workflow

```
1. AUDIT SCOPE: [name] → Claude Code checks reality
2. Share audit with Architect AI (Claude Web/ChatGPT)
3. Brainstorm specs with Architect AI
4. SCOPE UPDATED: [name] → ROLE TRANSITION
5. Claude Code issues execution orders (decisions FROZEN)
6. Execute each order, confirm with evidence
7. Repeat until complete → LOCK scope
```

### Authority Rules

| Rule | Description |
|------|-------------|
| **Decision Authority** | Human decides WHAT (during brainstorming) |
| **Execution Authority** | AI decides HOW (during execution) |
| **Scope Locking** | Scopes unlock only when prerequisites complete |
| **Task Locking** | Completed tasks are locked states |
| **Failure Handling** | Failure is signal, not error — return to decision phase |

---

## Need Help?

- Read the full AIXORD eBook for detailed explanations
- Check SYSTEM_GUIDE.md for troubleshooting
- GitHub: https://github.com/peoplemerit
- Email: support@pmerit.com

---

*AIXORD v1.0 — Authority. Execution. Confirmation.*
