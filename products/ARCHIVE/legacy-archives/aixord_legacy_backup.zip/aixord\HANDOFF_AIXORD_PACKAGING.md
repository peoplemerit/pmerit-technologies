# HANDOFF — AIXORD Product Packaging

**From:** Director (Human)
**To:** Claude Code (Commander)
**Date:** 2025-12-29
**Mode:** EXECUTION
**Priority:** HIGH

---

## CONTEXT

You are packaging AIXORD distribution products for KDP (Amazon Kindle) and Gumroad. These are **customer-facing products** — simplified versions of the internal AIXORD v2.1 framework used for PMERIT development.

### Key Distinction

| Aspect | AIXORD v2.1 (Internal) | AIXORD Distribution (Products) |
|--------|------------------------|--------------------------------|
| **Purpose** | PMERIT platform development | Customer purchase/download |
| **Location** | `AIXORD_ROOT/` + `.claude/scopes/` | `products/aixord/distribution/` |
| **Complexity** | Full (SUB-SCOPEs, GENESIS, Sandbox) | Simplified (single-file templates) |
| **Audience** | You (Claude Code) | Customers using AI tools |

---

## PRODUCT INVENTORY

### Gumroad Products (8 SKUs)

| SKU | Product Name | Price | Contents |
|-----|--------------|-------|----------|
| AIXORD-CLAUDE | AIXORD for Claude | $9.99 | ZIP: Claude-optimized templates |
| AIXORD-CHATGPT | AIXORD for ChatGPT | $9.99 | ZIP: Single-file token-aware system |
| AIXORD-GEMINI | AIXORD for Gemini | $9.99 | ZIP: Google Docs integrated templates |
| AIXORD-COPILOT | AIXORD for GitHub Copilot | $9.99 | ZIP: IDE-focused templates |
| AIXORD-UNIVERSAL | AIXORD Universal | $14.99 | ZIP: All platform variants |
| AIXORD-STARTER | AIXORD Starter Pack | $19.99 | ZIP: Book + Templates + Quick Start |
| AIXORD-PRO | AIXORD Pro Bundle | $29.99 | ZIP: All variants + future updates |
| AIXORD-GENESIS | AIXORD GENESIS Protocol | $4.99 | ZIP: SCOPE creation templates only |

### KDP Books (8 Manuscripts)

| Book | Target Audience | Price | Discount Code |
|------|-----------------|-------|---------------|
| AIXORD: AI Execution Order Framework | Claude Code Pro users | $9.99 | Links to Gumroad templates |
| AIXORD for ChatGPT Users | ChatGPT Free/Plus users | $7.99 | 10% off AIXORD-CHATGPT |
| AIXORD for Gemini Users | Google Gemini users | $7.99 | 10% off AIXORD-GEMINI |
| AIXORD for GitHub Copilot | GitHub Copilot users | $7.99 | 10% off AIXORD-COPILOT |
| AIXORD Essentials | Beginners | $4.99 | 20% off any Gumroad product |
| AIXORD Visual Audit Playbook | QA/Compliance teams | $9.99 | Links to VA templates |
| AIXORD for Teams | Small dev teams | $12.99 | 15% off AIXORD-PRO |
| AIXORD Masterclass | Advanced users | $14.99 | Free AIXORD-GENESIS |

---

## EXECUTION ORDER

### Phase 1: Audit Current State

**Task:** Verify what exists in `products/aixord/`

```
products/aixord/
├── distribution/           <- Existing distribution files
│   ├── aixord-templates/   <- Template pack
│   ├── AIXORD_v1.1_KDP_6x9_FINAL.docx
│   ├── AIXORD_v1.1_KDP_6x9_FINAL.pdf
│   └── AMAZON_DESCRIPTION.html
├── v1/                     <- v1 source files
├── v2/                     <- v2 source files (in progress)
├── archive/                <- Old manuscript versions
└── [documentation files]
```

**Output:** Inventory report of existing assets

---

### Phase 2: Create Gumroad ZIPs

For each Gumroad product, create a ZIP with this structure:

```
[PRODUCT_NAME]/
├── README.md              <- Product overview, setup instructions
├── QUICK_START.md         <- 5-minute getting started
├── LICENSE.md             <- Usage terms
├── templates/
│   ├── CLAUDE.md          <- (or platform equivalent)
│   ├── SCOPE_TEMPLATE.md
│   ├── STATE.json
│   └── [platform-specific files]
└── examples/
    └── EXAMPLE_PROJECT/   <- Working example
```

**Naming Convention:** `AIXORD_[VARIANT]_v2.0.zip`

---

### Phase 3: Create KDP Manuscripts

Each KDP manuscript should be ~24+ pages with this structure:

```
MANUSCRIPT_AIXORD_[VARIANT].md

# [Title]
## [Subtitle]
By Idowu J Gabriel, Sr.

---

## Table of Contents

## Chapter 1: Introduction to AIXORD
## Chapter 2: Core Principles
## Chapter 3: The Three-Way Team
## Chapter 4: SCOPE System
## Chapter 5: Power Rules
## Chapter 6: [Platform-Specific] Setup
## Chapter 7: Example Workflow
## Chapter 8: Troubleshooting

## Appendix A: Template Reference
## Appendix B: Command Reference
## Appendix C: Discount Code (Gumroad)
## About the Author
```

---

### Phase 4: Create SCOPE_AIXORD

Create a proper SCOPE file for this product work:

```
.claude/scopes/SCOPE_AIXORD/
├── SCOPE_AIXORD.md
├── SUB-SCOPE_GUMROAD_PRODUCTS.md
├── SUB-SCOPE_KDP_MANUSCRIPTS.md
└── SUB-SCOPE_MARKETING.md
```

---

## COMMANDS

| Command | Action |
|---------|--------|
| `PRODUCT: AIXORD` | Load this SCOPE |
| `AUDIT: PRODUCTS` | List existing product files |
| `PACKAGE: [SKU]` | Create Gumroad ZIP for SKU |
| `MANUSCRIPT: [VARIANT]` | Create KDP manuscript |
| `STATUS: PRODUCTS` | Show packaging progress |

---

## FILE LOCATIONS

| Type | Path |
|------|------|
| **Product Source** | `Pmerit_Product_Development/products/aixord/` |
| **Distribution Output** | `Pmerit_Product_Development/products/aixord/distribution/` |
| **Manuscripts** | `Pmerit_Product_Development/products/aixord/manuscripts/` |
| **Gumroad ZIPs** | `Pmerit_Product_Development/products/aixord/distribution/gumroad/` |
| **SCOPE** | `Pmerit_Product_Development/.claude/scopes/SCOPE_AIXORD/` |

---

## PRICING RULES

1. **No free products** — Minimum $4.99
2. **Bundle savings** — Bundles save 20-30% vs individual
3. **KDP books reference Gumroad** — Include discount codes
4. **Discount codes format:** `AIXORD-[VARIANT]-[DISCOUNT]` (e.g., `AIXORD-CHATGPT-10`)

---

## ACCEPTANCE CRITERIA

### Phase 1: Audit
- [ ] Inventory of existing assets documented
- [ ] Gap analysis completed

### Phase 2: Gumroad ZIPs
- [ ] 8 ZIP files created
- [ ] Each ZIP has README, QUICK_START, templates/, examples/
- [ ] ZIPs tested (can be extracted, files readable)

### Phase 3: KDP Manuscripts
- [ ] 8 manuscripts created
- [ ] Each manuscript 24+ pages
- [ ] Discount codes included in appendix

### Phase 4: SCOPE Created
- [ ] SCOPE_AIXORD.md exists
- [ ] 3 SUB-SCOPEs created
- [ ] Linked from products CLAUDE.md

---

## HALT CONDITIONS

Stop and ask if:
- Unsure about pricing for a specific product
- Missing source content for a variant
- Need clarification on platform differences
- Conflicting information in existing files

---

*HANDOFF v1.0 — AIXORD Product Packaging*
*Created: 2025-12-29*
