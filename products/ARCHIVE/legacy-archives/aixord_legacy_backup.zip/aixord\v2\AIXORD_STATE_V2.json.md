# 📄 AIXORD_STATE_V2.json

```json
{
  "_comment": "AIXORD State File v2.0 — Single source of truth for project state",
  "_schema_version": "2.0",
  "_docs": "See AIXORD_GOVERNANCE_V2.md for field definitions",

  "project": {
    "name": "[PROJECT_NAME]",
    "repository": "[repo-path-or-url]",
    "created": "[YYYY-MM-DD]"
  },

  "session": {
    "number": 1,
    "started": null,
    "last_updated": null
  },

  "authority": {
    "decision": "human",
    "execution": "none",
    "transfer_log": []
  },

  "mode": {
    "current": "DECISION",
    "previous": null,
    "entered_at": null
  },

  "scope": {
    "active": null,
    "status": {}
  },

  "visual_audit": {
    "pending_scopes": [],
    "last_audit": null,
    "last_audit_scope": null
  },

  "halt": {
    "is_halted": false,
    "reason": null,
    "halted_at": null,
    "blockers": []
  },

  "continuity": {
    "last_handoff": null,
    "carryforward_items": [],
    "incomplete_tasks": []
  }
}
```

---

## 📖 Field Definitions

### `project`
| Field | Type | Description |
|-------|------|-------------|
| `name` | string | Project display name |
| `repository` | string | Local path or Git URL |
| `created` | date | When project was initialized |

### `session`
| Field | Type | Description |
|-------|------|-------------|
| `number` | integer | Auto-incremented session counter |
| `started` | datetime | When current session began |
| `last_updated` | datetime | Last state file modification |

### `authority`
| Field | Type | Description |
|-------|------|-------------|
| `decision` | enum | Who holds decision authority: `"human"` (always) |
| `execution` | enum | Who holds execution authority: `"none"` \| `"commander"` |
| `transfer_log` | array | History of authority transfers (audit trail) |

**Authority Transfer Log Entry:**
```json
{
  "timestamp": "2025-12-27T14:30:00Z",
  "from": "none",
  "to": "commander",
  "granted_by": "human",
  "scope": "SCOPE_AUTH",
  "reason": "ENTER EXECUTION MODE"
}
```

### `mode`
| Field | Type | Description |
|-------|------|-------------|
| `current` | enum | Active mode: `"DECISION"` \| `"EXECUTION"` \| `"AUDIT"` \| `"VISUAL_AUDIT"` |
| `previous` | enum | Mode before last transition |
| `entered_at` | datetime | When current mode was entered |

### `scope`
| Field | Type | Description |
|-------|------|-------------|
| `active` | string \| null | Currently loaded SCOPE name (e.g., `"SCOPE_AUTH"`) |
| `status` | object | Status of all known SCOPEs |

**Scope Status Object:**
```json
{
  "SCOPE_AUTH": {
    "state": "IN_PROGRESS",
    "last_updated": "2025-12-27",
    "visual_audit_required": true,
    "visual_audit_passed": false
  },
  "SCOPE_DATABASE": {
    "state": "LOCKED",
    "last_updated": "2025-12-20",
    "visual_audit_required": false,
    "visual_audit_passed": null
  }
}
```

**Valid SCOPE States:**
| State | Description |
|-------|-------------|
| `EMPTY` | File created, no content |
| `AUDITED` | AUDIT_REPORT populated |
| `SPECIFIED` | HANDOFF_DOCUMENT written |
| `IN_PROGRESS` | Execution underway |
| `VISUAL_AUDIT` | Visual verification in progress |
| `COMPLETE` | All requirements verified |
| `LOCKED` | Protected from modification |

### `visual_audit`
| Field | Type | Description |
|-------|------|-------------|
| `pending_scopes` | array | SCOPEs awaiting visual audit |
| `last_audit` | datetime | When last visual audit occurred |
| `last_audit_scope` | string | Which SCOPE was last audited |

### `halt`
| Field | Type | Description |
|-------|------|-------------|
| `is_halted` | boolean | Whether system is in HALT state |
| `reason` | string | Why halt was triggered |
| `halted_at` | datetime | When halt occurred |
| `blockers` | array | List of blocking issues |

**Blocker Entry:**
```json
{
  "id": "HALT-001",
  "type": "ambiguous_requirement",
  "description": "Payment flow unclear - Stripe or PayPal?",
  "raised_at": "2025-12-27T14:45:00Z",
  "resolved_at": null
}
```

**HALT Trigger Types (from Governance v2):**
| Type | Description |
|------|-------------|
| `ambiguous_requirement` | Spec is unclear |
| `scope_conflict` | SCOPEs have contradictions |
| `prerequisite_missing` | Dependency not met |
| `three_attempts_exceeded` | Implementation failed 3 times |
| `locked_file_modification` | Attempted to edit locked file |
| `authority_violation` | Wrong role tried an action |
| `human_issued` | Manual HALT command |
| `visual_discrepancy` | UI doesn't match spec after 2 fixes |

### `continuity`
| Field | Type | Description |
|-------|------|-------------|
| `last_handoff` | string | Filename of most recent handoff |
| `carryforward_items` | array | Items that must continue next session |
| `incomplete_tasks` | array | Tasks started but not finished |

---

## 📝 Example: Fresh Project State

```json
{
  "_comment": "AIXORD State File v2.0",
  "_schema_version": "2.0",
  "_docs": "See AIXORD_GOVERNANCE_V2.md for field definitions",

  "project": {
    "name": "My New Project",
    "repository": "C:/dev/my-project",
    "created": "2025-12-27"
  },

  "session": {
    "number": 1,
    "started": null,
    "last_updated": "2025-12-27T10:00:00Z"
  },

  "authority": {
    "decision": "human",
    "execution": "none",
    "transfer_log": []
  },

  "mode": {
    "current": "DECISION",
    "previous": null,
    "entered_at": "2025-12-27T10:00:00Z"
  },

  "scope": {
    "active": null,
    "status": {}
  },

  "visual_audit": {
    "pending_scopes": [],
    "last_audit": null,
    "last_audit_scope": null
  },

  "halt": {
    "is_halted": false,
    "reason": null,
    "halted_at": null,
    "blockers": []
  },

  "continuity": {
    "last_handoff": null,
    "carryforward_items": [],
    "incomplete_tasks": []
  }
}
```

---

## 📝 Example: Active Execution State

```json
{
  "_comment": "AIXORD State File v2.0",
  "_schema_version": "2.0",
  "_docs": "See AIXORD_GOVERNANCE_V2.md for field definitions",

  "project": {
    "name": "PMERIT Platform",
    "repository": "C:/dev/pmerit/pmerit-ai-platform",
    "created": "2024-06-15"
  },

  "session": {
    "number": 83,
    "started": "2025-12-27T14:00:00Z",
    "last_updated": "2025-12-27T16:45:00Z"
  },

  "authority": {
    "decision": "human",
    "execution": "commander",
    "transfer_log": [
      {
        "timestamp": "2025-12-27T14:15:00Z",
        "from": "none",
        "to": "commander",
        "granted_by": "human",
        "scope": "SCOPE_PARENT_PORTAL",
        "reason": "ENTER EXECUTION MODE for Phase B"
      }
    ]
  },

  "mode": {
    "current": "EXECUTION",
    "previous": "DECISION",
    "entered_at": "2025-12-27T14:15:00Z"
  },

  "scope": {
    "active": "SCOPE_PARENT_PORTAL",
    "status": {
      "SCOPE_HOMEPAGE": { "state": "LOCKED", "last_updated": "2025-12-10", "visual_audit_required": true, "visual_audit_passed": true },
      "SCOPE_DASHBOARD": { "state": "LOCKED", "last_updated": "2025-12-12", "visual_audit_required": true, "visual_audit_passed": true },
      "SCOPE_PARENT_PORTAL": { "state": "IN_PROGRESS", "last_updated": "2025-12-27", "visual_audit_required": true, "visual_audit_passed": false },
      "SCOPE_ADMIN": { "state": "SPECIFIED", "last_updated": "2025-12-20", "visual_audit_required": true, "visual_audit_passed": false }
    }
  },

  "visual_audit": {
    "pending_scopes": ["SCOPE_PARENT_PORTAL"],
    "last_audit": "2025-12-25T10:00:00Z",
    "last_audit_scope": "SCOPE_K12_EDUCATION"
  },

  "halt": {
    "is_halted": false,
    "reason": null,
    "halted_at": null,
    "blockers": []
  },

  "continuity": {
    "last_handoff": "HANDOFF_SESSION_82.md",
    "carryforward_items": ["Test age-out workflow", "Deploy email templates"],
    "incomplete_tasks": []
  }
}
```
