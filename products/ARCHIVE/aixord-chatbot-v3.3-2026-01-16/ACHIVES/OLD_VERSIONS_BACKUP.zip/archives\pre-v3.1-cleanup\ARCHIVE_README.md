# Pre-v3.1 Cleanup Archive

**Archived:** December 31, 2025
**Reason:** Distribution folder cleanup - obsolete files from earlier development

## Archived Files

### Old Manuscripts (Pre-KDP Template Fix)
- `MANUSCRIPT_BUILDER.docx`
- `MANUSCRIPT_CHATGPT.docx`
- `MANUSCRIPT_CLAUDE.docx`
- `MANUSCRIPT_COMPLETE.docx`
- `MANUSCRIPT_COPILOT.docx`
- `MANUSCRIPT_GEMINI.docx`
- `MANUSCRIPT_GENESIS.docx`
- `MANUSCRIPT_STARTER.docx`

These were:
- Missing "Common Use Cases" chapter
- Missing "AIXORD vs Traditional AI Chat" chapter
- Using old template without proper heading styles
- Only 21 pages (needed 24+ for KDP)

### Old Template
- `Template 6 x 9 in.docx` - Original template without properly defined heading styles

### Obsolete Scripts
- `consolidate.py` - Old consolidation script
- `final_consolidation.py` - Old consolidation script
- `update_manuscripts.py` - Old manuscript updater
- `update_zips.py` - Old ZIP updater
- `verify_all.py` - Old verification script
- `extract-docx.ps1` - Old extraction script
- `update-manuscripts.ps1` - Old update script

## Current State

Distribution folder now contains only:
- `staging/` - Active staging area for package contents
- `archives/` - Historical archives
- 8 ZIP packages (v3.1) - Production-ready for Gumroad

## New Tools Location

KDP manuscript conversion tools are now at:
`AIXORD_ROOT/TOOLS/kdp-manuscript-converter/`

---
*Archived as part of distribution cleanup*
