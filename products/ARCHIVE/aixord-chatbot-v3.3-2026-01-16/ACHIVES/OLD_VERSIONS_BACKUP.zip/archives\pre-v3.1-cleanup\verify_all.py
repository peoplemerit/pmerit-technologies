#!/usr/bin/env python3
"""
AIXORD Final Verification Script
Verifies all manuscripts and ZIP packages have been properly updated
"""

import os
import zipfile
from docx import Document

DIST_PATH = r"C:\dev\pmerit\Pmerit_Product_Development\products\aixord-chatbot\distribution"

# Expected configurations
MANUSCRIPTS = [
    "MANUSCRIPT_STARTER",
    "MANUSCRIPT_GENESIS",
    "MANUSCRIPT_CLAUDE",
    "MANUSCRIPT_CHATGPT",
    "MANUSCRIPT_GEMINI",
    "MANUSCRIPT_COPILOT",
    "MANUSCRIPT_BUILDER",
    "MANUSCRIPT_COMPLETE",
]

PACKAGES = [
    "aixord-starter.zip",
    "aixord-genesis.zip",
    "aixord-claude-pack.zip",
    "aixord-chatgpt-pack.zip",
    "aixord-gemini-pack.zip",
    "aixord-copilot-pack.zip",
    "aixord-builder-bundle.zip",
    "aixord-complete.zip",
]


def verify_manuscript(name):
    """Verify a manuscript has DISCLAIMER and First Session content."""
    docx_path = os.path.join(DIST_PATH, f"{name}.docx")

    if not os.path.exists(docx_path):
        return {"exists": False, "has_disclaimer": False, "has_first_session": False}

    doc = Document(docx_path)
    full_text = "\n".join([p.text for p in doc.paragraphs])

    has_disclaimer = "TERMS OF USE AND DISCLAIMER" in full_text or "NO WARRANTY" in full_text
    has_first_session = "First" in full_text and ("Session" in full_text or "AIXORD Session" in full_text)

    return {
        "exists": True,
        "has_disclaimer": has_disclaimer,
        "has_first_session": has_first_session,
        "paragraph_count": len(doc.paragraphs)
    }


def verify_zip(zip_name):
    """Verify a ZIP package has DISCLAIMER.md."""
    zip_path = os.path.join(DIST_PATH, zip_name)

    if not os.path.exists(zip_path):
        return {"exists": False, "has_disclaimer": False, "files": []}

    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        names = zip_ref.namelist()

    has_disclaimer = "DISCLAIMER.md" in names
    size_kb = os.path.getsize(zip_path) / 1024

    return {
        "exists": True,
        "has_disclaimer": has_disclaimer,
        "file_count": len(names),
        "size_kb": size_kb
    }


def main():
    print("=" * 60)
    print("AIXORD FINAL VERIFICATION REPORT")
    print("=" * 60)

    # Verify Manuscripts
    print("\n" + "-" * 60)
    print("MANUSCRIPTS")
    print("-" * 60)
    print(f"{'Manuscript':<25} {'Exists':<8} {'Disclaimer':<12} {'1st Session':<12}")
    print("-" * 60)

    manuscript_issues = []
    for name in MANUSCRIPTS:
        result = verify_manuscript(name)
        exists = "YES" if result["exists"] else "NO"
        disclaimer = "YES" if result.get("has_disclaimer") else "NO"
        first_session = "YES" if result.get("has_first_session") else "N/A"

        print(f"{name:<25} {exists:<8} {disclaimer:<12} {first_session:<12}")

        if not result["exists"] or not result.get("has_disclaimer"):
            manuscript_issues.append(name)

    # Verify ZIP Packages
    print("\n" + "-" * 60)
    print("ZIP PACKAGES")
    print("-" * 60)
    print(f"{'Package':<30} {'Exists':<8} {'Disclaimer':<12} {'Size (KB)':<10}")
    print("-" * 60)

    zip_issues = []
    for zip_name in PACKAGES:
        result = verify_zip(zip_name)
        exists = "YES" if result["exists"] else "NO"
        disclaimer = "YES" if result.get("has_disclaimer") else "NO"
        size = f"{result.get('size_kb', 0):.1f}" if result["exists"] else "N/A"

        print(f"{zip_name:<30} {exists:<8} {disclaimer:<12} {size:<10}")

        if not result["exists"] or not result.get("has_disclaimer"):
            zip_issues.append(zip_name)

    # Summary
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)

    manuscript_ok = len(MANUSCRIPTS) - len(manuscript_issues)
    zip_ok = len(PACKAGES) - len(zip_issues)

    print(f"Manuscripts: {manuscript_ok}/{len(MANUSCRIPTS)} passed")
    print(f"ZIP Packages: {zip_ok}/{len(PACKAGES)} passed")

    if manuscript_issues:
        print(f"\nManuscript issues: {', '.join(manuscript_issues)}")
    if zip_issues:
        print(f"ZIP issues: {', '.join(zip_issues)}")

    if not manuscript_issues and not zip_issues:
        print("\nALL VERIFICATIONS PASSED!")
        print("\nNext steps for Director:")
        print("1. Re-upload 8 ZIP packages to Gumroad")
        print("2. Re-upload 8 manuscripts to KDP")
    else:
        print("\nSOME VERIFICATIONS FAILED - Review required")

    print("=" * 60)


if __name__ == "__main__":
    main()
