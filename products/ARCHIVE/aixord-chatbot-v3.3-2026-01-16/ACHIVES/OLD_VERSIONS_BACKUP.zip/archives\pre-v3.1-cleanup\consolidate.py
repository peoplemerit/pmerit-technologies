#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AIXORD Final Consolidation Script
Executes all tasks from HANDOFF_FINAL_CONSOLIDATION_V1
"""

import os
import shutil
import zipfile
from datetime import datetime
from docx import Document
from docx.shared import Pt

DIST_PATH = r"C:\dev\pmerit\Pmerit_Product_Development\products\aixord-chatbot\distribution"
STAGING_PATH = os.path.join(DIST_PATH, "staging")
ARCHIVE_PATH = os.path.join(DIST_PATH, "archives")
TEMP_PATH = os.path.join(DIST_PATH, "temp_consolidation")

# Package configurations
PACKAGES = {
    "aixord-starter.zip": ["templates/", "examples/", "variants/"],
    "aixord-genesis.zip": ["templates/", "examples/", "variants/"],
    "aixord-claude-pack.zip": ["templates/", "examples/", "variants/"],
    "aixord-chatgpt-pack.zip": ["templates/", "examples/", "variants/"],
    "aixord-gemini-pack.zip": ["templates/", "examples/", "variants/"],
    "aixord-copilot-pack.zip": ["templates/", "examples/", "variants/"],
    "aixord-builder-bundle.zip": ["examples/", "variants/"],
    "aixord-complete.zip": [],
}

# Manuscript configurations
MANUSCRIPTS = {
    "MANUSCRIPT_STARTER": {
        "needs_session": False,
        "gumroad_url": "https://meritwise0.gumroad.com/l/ryysts",
        "discount_code": "AX-STR-7K9M",
        "product_name": "AIXORD Starter",
        "price": "$4.99"
    },
    "MANUSCRIPT_GENESIS": {
        "needs_session": True,
        "session_title": "YOUR FIRST GENESIS SESSION",
        "gumroad_url": "https://meritwise0.gumroad.com/l/nlrwyn",
        "discount_code": "AX-GEN-4P2X",
        "product_name": "AIXORD Genesis",
        "price": "$7.99"
    },
    "MANUSCRIPT_CLAUDE": {
        "needs_session": True,
        "session_title": "YOUR FIRST CLAUDE SESSION",
        "gumroad_url": "https://meritwise0.gumroad.com/l/zpnjv",
        "discount_code": "AX-CLD-8N5Q",
        "product_name": "AIXORD for Claude Users",
        "price": "$9.99"
    },
    "MANUSCRIPT_CHATGPT": {
        "needs_session": True,
        "session_title": "YOUR FIRST CHATGPT SESSION",
        "gumroad_url": "https://meritwise0.gumroad.com/l/jfnzh",
        "discount_code": "AX-GPT-3W7J",
        "product_name": "AIXORD for ChatGPT Users",
        "price": "$9.99"
    },
    "MANUSCRIPT_GEMINI": {
        "needs_session": True,
        "session_title": "YOUR FIRST GEMINI SESSION",
        "gumroad_url": "https://meritwise0.gumroad.com/l/qndnd",
        "discount_code": "AX-GEM-6R4T",
        "product_name": "AIXORD for Gemini Users",
        "price": "$7.99"
    },
    "MANUSCRIPT_COPILOT": {
        "needs_session": True,
        "session_title": "YOUR FIRST COPILOT SESSION",
        "gumroad_url": "https://meritwise0.gumroad.com/l/jctnyh",
        "discount_code": "AX-CPL-9V2H",
        "product_name": "AIXORD for Copilot Users",
        "price": "$4.99"
    },
    "MANUSCRIPT_BUILDER": {
        "needs_session": True,
        "session_title": "YOUR FIRST BUILDER SESSION",
        "gumroad_url": "https://meritwise0.gumroad.com/l/ennzm",
        "discount_code": "AX-BLD-5K8N",
        "product_name": "AIXORD Builder's Toolkit",
        "price": "$17.99"
    },
    "MANUSCRIPT_COMPLETE": {
        "needs_session": True,
        "session_title": "YOUR FIRST AIXORD SESSION",
        "gumroad_url": "https://meritwise0.gumroad.com/l/xtwqj",
        "discount_code": "AX-CMP-2M6Y",
        "product_name": "AIXORD: The Complete Framework",
        "price": "$29.99"
    },
}

TEMPLATES_README = """# Templates

This folder contains AIXORD templates for your projects.

See the main README.md for usage instructions.
"""

EXAMPLES_README = """# Examples

This folder contains example AIXORD sessions and configurations.

See the main README.md for usage instructions.
"""

VARIANTS_README = """# Variants

This folder contains platform-specific AIXORD variants.

See the main README.md for usage instructions.
"""


def task1_verify_disclaimer():
    """Task 1: Verify DISCLAIMER.md in all ZIPs."""
    print("\n" + "=" * 60)
    print("TASK 1: Verify DISCLAIMER.md in all ZIPs")
    print("=" * 60)

    disclaimer_path = os.path.join(STAGING_PATH, "DISCLAIMER.md")
    if not os.path.exists(disclaimer_path):
        print("  ERROR: DISCLAIMER.md not found in staging!")
        return False

    disclaimer_content = open(disclaimer_path, 'r', encoding='utf-8').read()

    for zip_name in PACKAGES.keys():
        zip_path = os.path.join(DIST_PATH, zip_name)
        if not os.path.exists(zip_path):
            print(f"  SKIP: {zip_name} not found")
            continue

        with zipfile.ZipFile(zip_path, 'r') as zf:
            has_disclaimer = "DISCLAIMER.md" in zf.namelist()

        if has_disclaimer:
            print(f"  {zip_name}: DISCLAIMER.md present [OK]")
        else:
            print(f"  {zip_name}: Adding DISCLAIMER.md...")
            extract_path = os.path.join(TEMP_PATH, zip_name.replace('.zip', ''))
            os.makedirs(extract_path, exist_ok=True)

            with zipfile.ZipFile(zip_path, 'r') as zf:
                zf.extractall(extract_path)

            with open(os.path.join(extract_path, "DISCLAIMER.md"), 'w', encoding='utf-8') as f:
                f.write(disclaimer_content)

            os.remove(zip_path)
            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
                for root, dirs, files in os.walk(extract_path):
                    for file in files:
                        file_path = os.path.join(root, file)
                        arcname = os.path.relpath(file_path, extract_path)
                        zf.write(file_path, arcname)

            shutil.rmtree(extract_path)
            print(f"    Added [OK]")

    return True


def task2_normalize_folders():
    """Task 2: Add missing folders to ZIPs."""
    print("\n" + "=" * 60)
    print("TASK 2: Normalize ZIP folder structure")
    print("=" * 60)

    for zip_name, missing_folders in PACKAGES.items():
        zip_path = os.path.join(DIST_PATH, zip_name)
        if not os.path.exists(zip_path):
            print(f"  SKIP: {zip_name} not found")
            continue

        if not missing_folders:
            print(f"  {zip_name}: Already compliant [OK]")
            continue

        print(f"  {zip_name}: Adding {missing_folders}...")

        extract_path = os.path.join(TEMP_PATH, zip_name.replace('.zip', ''))
        if os.path.exists(extract_path):
            shutil.rmtree(extract_path)
        os.makedirs(extract_path)

        with zipfile.ZipFile(zip_path, 'r') as zf:
            zf.extractall(extract_path)

        for folder in missing_folders:
            folder_name = folder.rstrip('/')
            folder_path = os.path.join(extract_path, folder_name)
            os.makedirs(folder_path, exist_ok=True)

            readme_path = os.path.join(folder_path, "README.md")
            if not os.path.exists(readme_path):
                if folder_name == "templates":
                    content = TEMPLATES_README
                elif folder_name == "examples":
                    content = EXAMPLES_README
                elif folder_name == "variants":
                    content = VARIANTS_README
                else:
                    content = f"# {folder_name.title()}\n\nSee main README.md for details.\n"

                with open(readme_path, 'w', encoding='utf-8') as f:
                    f.write(content)

        os.remove(zip_path)
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            for root, dirs, files in os.walk(extract_path):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, extract_path)
                    zf.write(file_path, arcname)

        shutil.rmtree(extract_path)
        print(f"    Done [OK]")

    return True


def get_session_content(manuscript_name):
    """Get first session chapter content."""
    staging_file = os.path.join(STAGING_PATH, f"FIRST_SESSION_{manuscript_name.replace('MANUSCRIPT_', '')}.txt")
    if os.path.exists(staging_file):
        return open(staging_file, 'r', encoding='utf-8').read()
    return None


def get_download_appendix(config):
    """Generate download appendix content."""
    return f"""APPENDIX: DOWNLOAD YOUR TEMPLATES

This book includes downloadable AIXORD templates and resources.

HOW TO DOWNLOAD

1. Visit: {config.get('gumroad_url', 'https://meritwise0.gumroad.com')}

2. Use discount code: {config.get('discount_code', 'N/A')} for your exclusive reader discount

3. Complete checkout and download the ZIP package

4. Extract the ZIP to a folder on your computer

WHAT'S INCLUDED

Your download contains:

- README.md: Getting started guide
- DISCLAIMER.md: Terms of use
- quick-start/: Quick reference materials
  - CHEAT_SHEET.md: Print-ready command reference
  - COMMAND_CARD.md: Complete command guide
  - CLAUDE_WEB_INSTRUCTIONS.md: Project setup
- templates/: AIXORD templates
- examples/: Sample sessions
- variants/: Platform-specific variants

QUICK START

1. Read CHEAT_SHEET.md (2 minutes)
2. Copy CLAUDE_WEB_INSTRUCTIONS.md into your AI project settings
3. Start with: [PROJECT] CONTINUE

YOUR ACCESS CODE

Product: {config.get('product_name', 'AIXORD')}
Regular Price: {config.get('price', 'N/A')}
Your Price: FREE (with code)
Code: {config.get('discount_code', 'N/A')}

SUPPORT

Questions? Contact: support@pmerit.com

(c) 2025 PMERIT LLC"""


def find_para_idx(doc, text):
    """Find paragraph index containing text."""
    for i, para in enumerate(doc.paragraphs):
        if text.lower() in para.text.lower():
            return i
    return -1


def task3_4_update_manuscripts():
    """Tasks 3-4: Add first session chapters and download appendix."""
    print("\n" + "=" * 60)
    print("TASKS 3-4: Update Manuscripts")
    print("=" * 60)

    for name, config in MANUSCRIPTS.items():
        docx_path = os.path.join(DIST_PATH, f"{name}.docx")
        if not os.path.exists(docx_path):
            print(f"  SKIP: {name}.docx not found")
            continue

        print(f"\n  Processing: {name}")

        # Backup
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = os.path.join(ARCHIVE_PATH, f"{name}_final_backup_{timestamp}.docx")
        shutil.copy2(docx_path, backup_path)
        print(f"    Backed up [OK]")

        doc = Document(docx_path)
        full_text = "\n".join([p.text for p in doc.paragraphs])

        has_session = config.get("session_title", "") in full_text or "Your First" in full_text
        has_download = "DOWNLOAD YOUR TEMPLATES" in full_text or "HOW TO DOWNLOAD" in full_text
        has_discount = config.get("discount_code", "") in full_text

        print(f"    Has First Session: {'[OK]' if has_session else '[X]'}")
        print(f"    Has Download Appendix: {'[OK]' if has_download else '[X]'}")
        print(f"    Has Discount Code: {'[OK]' if has_discount else '[X]'}")

        modified = False

        # Add First Session if needed
        if config.get("needs_session") and not has_session:
            print(f"    Adding First Session chapter...")
            content = get_session_content(name)
            if content:
                insert_idx = find_para_idx(doc, "Quick Reference")
                if insert_idx == -1:
                    insert_idx = find_para_idx(doc, "Appendix A")
                if insert_idx == -1:
                    insert_idx = find_para_idx(doc, "Glossary")

                if insert_idx > 0:
                    lines = content.strip().split('\n')
                    for line in reversed(lines):
                        line = line.strip()
                        if line:
                            new_para = doc.paragraphs[insert_idx].insert_paragraph_before(line)
                            if line.startswith("YOUR FIRST") or line.startswith("Chapter:"):
                                for run in new_para.runs:
                                    run.bold = True
                                    run.font.size = Pt(16)
                            elif line.startswith("STEP ") or line.startswith("PHASE ") or line.startswith("THE ") or line.startswith("WHAT YOU") or line.startswith("PREPARATION"):
                                for run in new_para.runs:
                                    run.bold = True
                    modified = True
                    print(f"      Added [OK]")

        # Add Download Appendix if not present
        if not has_download:
            print(f"    Adding Download Appendix...")
            appendix_content = get_download_appendix(config)

            insert_idx = find_para_idx(doc, "About the Author")
            if insert_idx == -1:
                insert_idx = len(doc.paragraphs) - 1

            if insert_idx > 0:
                lines = appendix_content.strip().split('\n')
                for line in reversed(lines):
                    line = line.strip()
                    if line:
                        new_para = doc.paragraphs[insert_idx].insert_paragraph_before(line)
                        if line.startswith("APPENDIX"):
                            for run in new_para.runs:
                                run.bold = True
                                run.font.size = Pt(16)
                        elif line.startswith("HOW TO") or line.startswith("WHAT'S") or line.startswith("QUICK START") or line.startswith("YOUR ACCESS") or line.startswith("SUPPORT"):
                            for run in new_para.runs:
                                run.bold = True
                modified = True
                print(f"      Added [OK]")

        if modified:
            doc.save(docx_path)
            print(f"    Saved [OK]")
        else:
            print(f"    No changes needed")

    return True


def final_verification():
    """Final verification."""
    print("\n" + "=" * 60)
    print("FINAL VERIFICATION")
    print("=" * 60)

    all_pass = True

    print("\nZIP Packages:")
    for zip_name in PACKAGES.keys():
        zip_path = os.path.join(DIST_PATH, zip_name)
        if not os.path.exists(zip_path):
            print(f"  {zip_name}: NOT FOUND [X]")
            all_pass = False
            continue

        with zipfile.ZipFile(zip_path, 'r') as zf:
            names = zf.namelist()

        checks = {
            "DISCLAIMER.md": "DISCLAIMER.md" in names,
            "templates/": any("templates/" in n for n in names),
            "examples/": any("examples/" in n for n in names),
            "variants/": any("variants/" in n for n in names),
        }

        passed = all(checks.values())
        status = "[OK]" if passed else "[X]"
        print(f"  {zip_name}: {status}")
        if not passed:
            all_pass = False
            for check, result in checks.items():
                if not result:
                    print(f"    Missing: {check}")

    print("\nManuscripts:")
    for name, config in MANUSCRIPTS.items():
        docx_path = os.path.join(DIST_PATH, f"{name}.docx")
        if not os.path.exists(docx_path):
            print(f"  {name}: NOT FOUND [X]")
            all_pass = False
            continue

        doc = Document(docx_path)
        full_text = "\n".join([p.text for p in doc.paragraphs])

        checks = {
            "DISCLAIMER": "NO WARRANTY" in full_text or "TERMS OF USE" in full_text,
            "First Session": not config.get("needs_session") or "Your First" in full_text or config.get("session_title", "") in full_text,
            "Download Appendix": "DOWNLOAD YOUR TEMPLATES" in full_text or "HOW TO DOWNLOAD" in full_text,
            "Discount Code": config.get("discount_code", "") in full_text,
        }

        passed = all(checks.values())
        status = "[OK]" if passed else "[X]"
        print(f"  {name}: {status}")
        if not passed:
            all_pass = False
            for check, result in checks.items():
                if not result:
                    print(f"    Missing: {check}")

    print("\n" + "=" * 60)
    if all_pass:
        print("ALL VERIFICATIONS PASSED!")
    else:
        print("SOME VERIFICATIONS FAILED - Review required")
    print("=" * 60)

    return all_pass


def main():
    print("=" * 60)
    print("AIXORD FINAL CONSOLIDATION SCRIPT")
    print("=" * 60)

    os.makedirs(ARCHIVE_PATH, exist_ok=True)
    os.makedirs(TEMP_PATH, exist_ok=True)
    os.makedirs(STAGING_PATH, exist_ok=True)

    task1_verify_disclaimer()
    task2_normalize_folders()
    task3_4_update_manuscripts()

    if os.path.exists(TEMP_PATH):
        shutil.rmtree(TEMP_PATH)

    final_verification()

    print("\n" + "=" * 60)
    print("CONSOLIDATION COMPLETE")
    print("=" * 60)
    print("\nNext Steps for Director:")
    print("1. Review manuscripts in Word for formatting")
    print("2. Prepare NDA for testers")
    print("3. Package for Nigerian testers")
    print("4. Distribute after NDA signed")


if __name__ == "__main__":
    main()
