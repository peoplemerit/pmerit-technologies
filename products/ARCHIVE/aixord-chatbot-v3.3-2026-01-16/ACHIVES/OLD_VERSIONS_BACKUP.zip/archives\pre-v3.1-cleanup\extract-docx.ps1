# Extract text content from DOCX files for auditing
$distPath = "C:\dev\pmerit\Pmerit_Product_Development\products\aixord-chatbot\distribution"
$tempPath = "$distPath\temp_audit"

# List of manuscripts to audit
$manuscripts = @(
    "MANUSCRIPT_STARTER",
    "MANUSCRIPT_GENESIS",
    "MANUSCRIPT_CLAUDE",
    "MANUSCRIPT_CHATGPT",
    "MANUSCRIPT_GEMINI",
    "MANUSCRIPT_COPILOT",
    "MANUSCRIPT_BUILDER",
    "MANUSCRIPT_COMPLETE"
)

# Also extract template
$allFiles = $manuscripts + @("Template 6 x 9 in")

foreach ($name in $allFiles) {
    $docxPath = "$distPath\$name.docx"
    if (Test-Path $docxPath) {
        $zipPath = "$tempPath\$name.zip"
        $extractPath = "$tempPath\$name"

        # Copy and extract
        Copy-Item $docxPath $zipPath -Force
        Expand-Archive -Path $zipPath -DestinationPath $extractPath -Force

        # Extract text from document.xml
        $xmlPath = "$extractPath\word\document.xml"
        if (Test-Path $xmlPath) {
            $content = Get-Content $xmlPath -Raw
            # Simple regex to extract text between XML tags
            $text = [regex]::Replace($content, '<[^>]+>', ' ')
            $text = [regex]::Replace($text, '\s+', ' ')
            $text | Out-File "$tempPath\${name}_content.txt" -Encoding UTF8
            Write-Host "Extracted: $name"
        }
    } else {
        Write-Host "Not found: $docxPath"
    }
}

Write-Host "Done! Check temp_audit folder for _content.txt files"
