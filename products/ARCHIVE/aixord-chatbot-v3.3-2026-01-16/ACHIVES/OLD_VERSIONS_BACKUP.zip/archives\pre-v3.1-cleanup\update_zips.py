#!/usr/bin/env python3
"""
AIXORD ZIP Package Update Script
Adds DISCLAIMER.md to all ZIP packages
"""

import os
import shutil
import zipfile
from datetime import datetime

DIST_PATH = r"C:\dev\pmerit\Pmerit_Product_Development\products\aixord-chatbot\distribution"
STAGING_PATH = os.path.join(DIST_PATH, "staging")
ARCHIVE_PATH = os.path.join(DIST_PATH, "archives")
TEMP_PATH = os.path.join(DIST_PATH, "temp_zip_update")

# ZIP packages to update
PACKAGES = [
    "aixord-starter.zip",
    "aixord-genesis.zip",
    "aixord-claude-pack.zip",
    "aixord-chatgpt-pack.zip",
    "aixord-gemini-pack.zip",
    "aixord-copilot-pack.zip",
    "aixord-builder-bundle.zip",
    "aixord-complete.zip",
]

def update_zip_with_disclaimer(zip_name):
    """Add DISCLAIMER.md to a ZIP package."""
    zip_path = os.path.join(DIST_PATH, zip_name)
    disclaimer_path = os.path.join(STAGING_PATH, "DISCLAIMER.md")

    if not os.path.exists(zip_path):
        print(f"  SKIP: {zip_name} not found")
        return False

    if not os.path.exists(disclaimer_path):
        print(f"  ERROR: DISCLAIMER.md not found in staging")
        return False

    print(f"  Processing: {zip_name}")

    # Backup original
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = os.path.join(ARCHIVE_PATH, f"{zip_name.replace('.zip', '')}_disclaimer_backup_{timestamp}.zip")
    shutil.copy2(zip_path, backup_path)
    print(f"    Backed up to: {os.path.basename(backup_path)}")

    # Extract to temp
    extract_path = os.path.join(TEMP_PATH, zip_name.replace('.zip', ''))
    if os.path.exists(extract_path):
        shutil.rmtree(extract_path)
    os.makedirs(extract_path)

    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_path)

    # Copy DISCLAIMER.md to root of extracted contents
    shutil.copy2(disclaimer_path, os.path.join(extract_path, "DISCLAIMER.md"))
    print(f"    Added DISCLAIMER.md to package root")

    # Recreate ZIP
    os.remove(zip_path)
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zip_ref:
        for root, dirs, files in os.walk(extract_path):
            for file in files:
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, extract_path)
                zip_ref.write(file_path, arcname)

    # Get new size
    new_size = os.path.getsize(zip_path) / 1024
    print(f"    New size: {new_size:.1f} KB")

    # Cleanup
    shutil.rmtree(extract_path)

    return True


def verify_zip_contents(zip_name):
    """Verify DISCLAIMER.md is in the ZIP."""
    zip_path = os.path.join(DIST_PATH, zip_name)

    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        names = zip_ref.namelist()
        has_disclaimer = "DISCLAIMER.md" in names
        return has_disclaimer, names


def main():
    print("=" * 50)
    print("AIXORD ZIP Package Update Script")
    print("=" * 50)

    # Ensure directories exist
    os.makedirs(ARCHIVE_PATH, exist_ok=True)
    os.makedirs(TEMP_PATH, exist_ok=True)

    print("\nPhase 1: Adding DISCLAIMER.md to packages...")
    success_count = 0
    for zip_name in PACKAGES:
        try:
            if update_zip_with_disclaimer(zip_name):
                success_count += 1
        except Exception as e:
            print(f"    ERROR: {str(e)}")

    print(f"\n  Updated: {success_count}/{len(PACKAGES)} packages")

    print("\nPhase 2: Verifying contents...")
    all_verified = True
    for zip_name in PACKAGES:
        try:
            has_disclaimer, files = verify_zip_contents(zip_name)
            status = "PASS" if has_disclaimer else "FAIL"
            print(f"  {zip_name}: {status}")
            if not has_disclaimer:
                all_verified = False
        except Exception as e:
            print(f"  {zip_name}: ERROR - {str(e)}")
            all_verified = False

    # Cleanup temp directory
    if os.path.exists(TEMP_PATH):
        shutil.rmtree(TEMP_PATH)

    print("\n" + "=" * 50)
    if all_verified:
        print("All packages verified successfully!")
    else:
        print("Some packages failed verification!")
    print("=" * 50)


if __name__ == "__main__":
    main()
