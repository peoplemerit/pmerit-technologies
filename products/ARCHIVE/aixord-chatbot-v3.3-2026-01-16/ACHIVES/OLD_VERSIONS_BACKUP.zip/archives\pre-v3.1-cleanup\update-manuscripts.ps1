# AIXORD Manuscript Update Script
# Adds DISCLAIMER chapter and "Your First AIXORD Session" to manuscripts

$distPath = "C:\dev\pmerit\Pmerit_Product_Development\products\aixord-chatbot\distribution"
$stagingPath = "$distPath\staging"
$tempPath = "$distPath\temp_update"
$archivePath = "$distPath\archives"

# Create directories
New-Item -ItemType Directory -Force -Path $tempPath | Out-Null
New-Item -ItemType Directory -Force -Path $archivePath | Out-Null

# Manuscript configurations
$manuscripts = @{
    "MANUSCRIPT_STARTER" = @{
        "needs_first_session" = $false  # Already has it
        "first_session_file" = $null
    }
    "MANUSCRIPT_GENESIS" = @{
        "needs_first_session" = $true
        "first_session_file" = "FIRST_SESSION_GENESIS.txt"
    }
    "MANUSCRIPT_CLAUDE" = @{
        "needs_first_session" = $true
        "first_session_file" = "FIRST_SESSION_CLAUDE.txt"
    }
    "MANUSCRIPT_CHATGPT" = @{
        "needs_first_session" = $true
        "first_session_file" = "FIRST_SESSION_CHATGPT.txt"
    }
    "MANUSCRIPT_GEMINI" = @{
        "needs_first_session" = $true
        "first_session_file" = "FIRST_SESSION_GEMINI.txt"
    }
    "MANUSCRIPT_COPILOT" = @{
        "needs_first_session" = $true
        "first_session_file" = "FIRST_SESSION_COPILOT.txt"
    }
    "MANUSCRIPT_BUILDER" = @{
        "needs_first_session" = $true
        "first_session_file" = "FIRST_SESSION_BUILDER.txt"
    }
    "MANUSCRIPT_COMPLETE" = @{
        "needs_first_session" = $true
        "first_session_file" = "FIRST_SESSION_COMPLETE.txt"
    }
}

# DISCLAIMER content for manuscripts (condensed version)
$disclaimerContent = @"
TERMS OF USE AND DISCLAIMER

By using this book and the AIXORD methodology, you agree to the following terms:

NO WARRANTY: AIXORD products are provided "AS IS" without warranty of any kind.

NO GUARANTEE OF RESULTS: Your results depend on your implementation, project requirements, and the AI platforms you use.

NOT PROFESSIONAL ADVICE: AIXORD is not a substitute for legal, financial, medical, or other professional advice.

USER RESPONSIBILITY: You are solely responsible for reviewing AI outputs and making final decisions. The "Director" role explicitly places decision-making authority with you.

PROHIBITED USES: You may not use AIXORD to generate harmful content, engage in fraud, create malware, reverse-engineer for resale, or violate AI platform terms of service.

LIMITATION OF LIABILITY: PMERIT LLC is not liable for any damages exceeding the amount you paid for this product.

DISPUTE RESOLUTION: Disputes are resolved by binding arbitration in Maine. You waive your right to participate in class actions.

INTELLECTUAL PROPERTY: AIXORD methodology remains the property of PMERIT LLC. You receive a non-exclusive, non-transferable license for personal and organizational use.

Full terms available at: https://pmerit.com/aixord-terms

Contact: legal@pmerit.com | support@pmerit.com

(c) 2025 PMERIT LLC. All Rights Reserved.
"@

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "AIXORD Manuscript Update Script" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

foreach ($name in $manuscripts.Keys) {
    $docxPath = "$distPath\$name.docx"

    if (-not (Test-Path $docxPath)) {
        Write-Host "SKIP: $name.docx not found" -ForegroundColor Yellow
        continue
    }

    Write-Host "Processing: $name" -ForegroundColor Green

    # Backup original
    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $backupPath = "$archivePath\${name}_backup_$timestamp.docx"
    Copy-Item $docxPath $backupPath
    Write-Host "  - Backed up to archives" -ForegroundColor Gray

    # Extract DOCX
    $extractPath = "$tempPath\$name"
    $zipPath = "$tempPath\$name.zip"

    if (Test-Path $extractPath) {
        Remove-Item $extractPath -Recurse -Force
    }

    Copy-Item $docxPath $zipPath
    Expand-Archive -Path $zipPath -DestinationPath $extractPath -Force
    Remove-Item $zipPath

    # Read document.xml
    $docXmlPath = "$extractPath\word\document.xml"
    $content = Get-Content $docXmlPath -Raw -Encoding UTF8

    # We need to insert content into the XML
    # This is complex - for now, let's report what needs to be done

    $config = $manuscripts[$name]

    if ($config.needs_first_session) {
        Write-Host "  - Needs 'Your First AIXORD Session' chapter" -ForegroundColor Yellow
        $sessionFile = "$stagingPath\$($config.first_session_file)"
        if (Test-Path $sessionFile) {
            Write-Host "    Content file: $($config.first_session_file)" -ForegroundColor Gray
        }
    } else {
        Write-Host "  - Already has first session chapter" -ForegroundColor Gray
    }

    Write-Host "  - Needs DISCLAIMER chapter" -ForegroundColor Yellow

    # Clean up temp
    Remove-Item $extractPath -Recurse -Force
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "MANUAL STEPS REQUIRED" -ForegroundColor Yellow
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "DOCX files are complex XML. Direct editing requires:" -ForegroundColor White
Write-Host "1. Proper paragraph/run structure" -ForegroundColor White
Write-Host "2. Style definitions" -ForegroundColor White
Write-Host "3. Numbering for chapters" -ForegroundColor White
Write-Host ""
Write-Host "RECOMMENDATION: Use Microsoft Word or python-docx for reliable editing." -ForegroundColor Cyan
Write-Host ""
Write-Host "Content files created in staging folder:" -ForegroundColor Green
Get-ChildItem "$stagingPath\*.txt" | ForEach-Object { Write-Host "  - $($_.Name)" }
Write-Host ""
Write-Host "DISCLAIMER.md created for ZIP packages." -ForegroundColor Green
