﻿#!/usr/bin/env python3
"""
AIXORD Final Consolidation Script
Executes all tasks from HANDOFF_FINAL_CONSOLIDATION_V1
"""

import os
import shutil
import zipfile
from datetime import datetime
from docx import Document
from docx.shared import Pt, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

DIST_PATH = r"C:\dev\pmerit\Pmerit_Product_Development\products\aixord-chatbot\distribution"
STAGING_PATH = os.path.join(DIST_PATH, "staging")
ARCHIVE_PATH = os.path.join(DIST_PATH, "archives")
TEMP_PATH = os.path.join(DIST_PATH, "temp_consolidation")
DISCLAIMER_PATH = r"C:\dev\pmerit\Pmerit_Product_Development\products\aixord-chatbot\INTERSESSION_CHAT_ACCESS\DISCLAIMER_V2.md"

# Package configurations
PACKAGES = {
    "aixord-starter.zip": {"missing": ["templates/", "examples/", "variants/"]},
    "aixord-genesis.zip": {"missing": ["templates/", "examples/", "variants/"]},
    "aixord-claude-pack.zip": {"missing": ["templates/", "examples/", "variants/"]},
    "aixord-chatgpt-pack.zip": {"missing": ["templates/", "examples/", "variants/"]},
    "aixord-gemini-pack.zip": {"missing": ["templates/", "examples/", "variants/"]},
    "aixord-copilot-pack.zip": {"missing": ["templates/", "examples/", "variants/"]},
    "aixord-builder-bundle.zip": {"missing": ["examples/", "variants/"]},
    "aixord-complete.zip": {"missing": []},
}

# Manuscript configurations with Gumroad URLs and discount codes
MANUSCRIPTS = {
    "MANUSCRIPT_STARTER": {
        "session_chapter": None,  # Already has it
        "gumroad_url": "https://meritwise0.gumroad.com/l/ryysts",
        "discount_code": "AX-STR-7K9M",
        "product_name": "AIXORD Starter",
        "price": "$4.99"
    },
    "MANUSCRIPT_GENESIS": {
        "session_chapter": "FIRST_SESSION_GENESIS",
        "gumroad_url": "https://meritwise0.gumroad.com/l/nlrwyn",
        "discount_code": "AX-GEN-4P2X",
        "product_name": "AIXORD Genesis",
        "price": "$7.99"
    },
    "MANUSCRIPT_CLAUDE": {
        "session_chapter": "FIRST_SESSION_CLAUDE",
        "gumroad_url": "https://meritwise0.gumroad.com/l/zpnjv",
        "discount_code": "AX-CLD-8N5Q",
        "product_name": "AIXORD for Claude Users",
        "price": "$9.99"
    },
    "MANUSCRIPT_CHATGPT": {
        "session_chapter": "FIRST_SESSION_CHATGPT",
        "gumroad_url": "https://meritwise0.gumroad.com/l/jfnzh",
        "discount_code": "AX-GPT-3W7J",
        "product_name": "AIXORD for ChatGPT Users",
        "price": "$9.99"
    },
    "MANUSCRIPT_GEMINI": {
        "session_chapter": "FIRST_SESSION_GEMINI",
        "gumroad_url": "https://meritwise0.gumroad.com/l/qndnd",
        "discount_code": "AX-GEM-6R4T",
        "product_name": "AIXORD for Gemini Users",
        "price": "$7.99"
    },
    "MANUSCRIPT_COPILOT": {
        "session_chapter": "FIRST_SESSION_COPILOT",
        "gumroad_url": "https://meritwise0.gumroad.com/l/jctnyh",
        "discount_code": "AX-CPL-9V2H",
        "product_name": "AIXORD for Copilot Users",
        "price": "$4.99"
    },
    "MANUSCRIPT_BUILDER": {
        "session_chapter": "FIRST_SESSION_BUILDER",
        "gumroad_url": "https://meritwise0.gumroad.com/l/ennzm",
        "discount_code": "AX-BLD-5K8N",
        "product_name": "AIXORD Builder's Toolkit",
        "price": "$17.99"
    },
    "MANUSCRIPT_COMPLETE": {
        "session_chapter": "FIRST_SESSION_COMPLETE",
        "gumroad_url": "https://meritwise0.gumroad.com/l/xtwqj",
        "discount_code": "AX-CMP-2M6Y",
        "product_name": "AIXORD: The Complete Framework",
        "price": "$29.99"
    },
}

# Placeholder README contents
TEMPLATES_README = """# Templates

This folder contains AIXORD templates for your projects.

## Contents

- Core AIXORD governance templates
- SCOPE templates for common project types
- HANDOFF templates for session continuity

## Usage

1. Copy the appropriate template to your project
2. Customize the header section with your project details
3. Follow the governance rules defined in the template

See the main README.md for detailed usage instructions.
"""

EXAMPLES_README = """# Examples

This folder contains example AIXORD sessions and configurations.

## Contents

- Sample DECISION mode sessions
- Sample EXECUTION workflows
- Sample AUDIT reports

## Usage

Review these examples to understand how AIXORD governance works in practice.

See the main README.md for detailed usage instructions.
"""

VARIANTS_README = """# Variants

This folder contains platform-specific AIXORD variants.

## Contents

- Claude-optimized instructions
- ChatGPT-optimized instructions
- Gemini-optimized instructions
- Copilot-optimized instructions

## Usage

Choose the variant that matches your primary AI platform.

See the main README.md for detailed usage instructions.
"""


def verify_and_add_disclaimer_to_zips():
    """Task 1: Verify/Complete DISCLAIMER in all ZIPs."""
    print("\n" + "=" * 60)
    print("TASK 1: Verify/Add DISCLAIMER.md to all ZIPs")
    print("=" * 60)

    # Check if DISCLAIMER_V2.md exists
    if not os.path.exists(DISCLAIMER_PATH):
        # Use staging DISCLAIMER.md instead
        alt_disclaimer = os.path.join(STAGING_PATH, "DISCLAIMER.md")
        if os.path.exists(alt_disclaimer):
            disclaimer_content = open(alt_disclaimer, 'r', encoding='utf-8').read()
        else:
            print("ERROR: No DISCLAIMER file found!")
            return False
    else:
        disclaimer_content = open(DISCLAIMER_PATH, 'r', encoding='utf-8').read()

    for zip_name in PACKAGES.keys():
        zip_path = os.path.join(DIST_PATH, zip_name)
        if not os.path.exists(zip_path):
            print(f"  SKIP: {zip_name} not found")
            continue

        # Check if DISCLAIMER.md exists
        with zipfile.ZipFile(zip_path, 'r') as zf:
            has_disclaimer = "DISCLAIMER.md" in zf.namelist()

        if has_disclaimer:
            print(f"  {zip_name}: DISCLAIMER.md present [OK]")
        else:
            print(f"  {zip_name}: Adding DISCLAIMER.md...")
            # Extract, add, repack
            extract_path = os.path.join(TEMP_PATH, zip_name.replace('.zip', ''))
            os.makedirs(extract_path, exist_ok=True)

            with zipfile.ZipFile(zip_path, 'r') as zf:
                zf.extractall(extract_path)

            # Write DISCLAIMER.md
            with open(os.path.join(extract_path, "DISCLAIMER.md"), 'w', encoding='utf-8') as f:
                f.write(disclaimer_content)

            # Repack
            os.remove(zip_path)
            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
                for root, dirs, files in os.walk(extract_path):
                    for file in files:
                        file_path = os.path.join(root, file)
                        arcname = os.path.relpath(file_path, extract_path)
                        zf.write(file_path, arcname)

            shutil.rmtree(extract_path)
            print(f"    Added âœ“")

    return True


def normalize_zip_folder_structure():
    """Task 2: Add missing folders to ZIPs."""
    print("\n" + "=" * 60)
    print("TASK 2: Normalize ZIP folder structure")
    print("=" * 60)

    for zip_name, config in PACKAGES.items():
        zip_path = os.path.join(DIST_PATH, zip_name)
        if not os.path.exists(zip_path):
            print(f"  SKIP: {zip_name} not found")
            continue

        missing = config.get("missing", [])
        if not missing:
            print(f"  {zip_name}: Already compliant âœ“")
            continue

        print(f"  {zip_name}: Adding {missing}...")

        # Extract
        extract_path = os.path.join(TEMP_PATH, zip_name.replace('.zip', ''))
        if os.path.exists(extract_path):
            shutil.rmtree(extract_path)
        os.makedirs(extract_path)

        with zipfile.ZipFile(zip_path, 'r') as zf:
            zf.extractall(extract_path)

        # Add missing folders with README.md
        for folder in missing:
            folder_name = folder.rstrip('/')
            folder_path = os.path.join(extract_path, folder_name)
            os.makedirs(folder_path, exist_ok=True)

            readme_path = os.path.join(folder_path, "README.md")
            if not os.path.exists(readme_path):
                if folder_name == "templates":
                    content = TEMPLATES_README
                elif folder_name == "examples":
                    content = EXAMPLES_README
                elif folder_name == "variants":
                    content = VARIANTS_README
                else:
                    content = f"# {folder_name.title()}\n\nSee main README.md for details.\n"

                with open(readme_path, 'w', encoding='utf-8') as f:
                    f.write(content)

        # Repack
        os.remove(zip_path)
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            for root, dirs, files in os.walk(extract_path):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, extract_path)
                    zf.write(file_path, arcname)

        shutil.rmtree(extract_path)
        print(f"    Done âœ“")

    return True


def get_first_session_content(manuscript_name):
    """Get the First Session chapter content for a manuscript."""
    # First session chapter content for each manuscript
    chapters = {
        "FIRST_SESSION_GENESIS": """YOUR FIRST GENESIS SESSION

This chapter walks you through a complete Genesis workflowâ€”from raw idea to structured system.

THE SCENARIO

You have an idea: "I want to build a personal finance tracker app."

That's it. No specs, no requirements, no architecture. Just an idea.

Let's turn it into a system using AIXORD Genesis.

STEP 1: START THE SESSION

Open your AI assistant (Claude, ChatGPT, or Gemini) and paste your Genesis template. Then type:

    GENESIS CONTINUE

The AI will respond with a Genesis status report, indicating it's ready for ideation.

STEP 2: DECLARE YOUR IDEA

Type:

    IDEA: Personal finance tracker app that helps me understand where my money goes

The AI will acknowledge your idea and ask clarifying questions:
- Who is this for?
- What problem does it solve?
- What's the minimum viable version?

Answer naturally. The AI accumulates your decisions.

STEP 3: ENTER DECISION MODE

Once the AI has enough context, type:

    ENTER DECISION MODE

Now you're in structured brainstorming. The AI will help you:
- Define core features
- Identify user flows
- Establish boundaries (what's NOT included)

STEP 4: CRYSTALLIZE INTO SCOPE

When your decisions feel complete, type:

    CRYSTALLIZE SCOPE: FinanceTracker

The AI will generate a formal SCOPE document containing:
- Objective
- Requirements (numbered)
- Boundaries
- Success criteria

Review it. Request changes. When satisfied, type:

    APPROVED

STEP 5: HANDOFF TO EXECUTION

Your Genesis session is complete. You now have:
- A documented SCOPE
- Clear requirements
- Decision history

To begin building, create a HANDOFF document and transfer to your execution environment (Claude Code, VS Code, etc.).

WHAT YOU ACCOMPLISHED

In one session, you transformed "I want to build a finance app" into:
- Structured requirements
- Defined scope
- Documented decisions
- Execution-ready handoff

That's Genesis. Ideas become systems.""",

        "FIRST_SESSION_CLAUDE": """YOUR FIRST CLAUDE SESSION

This chapter walks you through setting up and running your first AIXORD session using Claude.

PREPARATION

Before starting:
1. Log into claude.ai
2. Create a new Project (click "Projects" â†’ "New Project")
3. Name it something meaningful (e.g., "My Website Project")

STEP 1: SET UP PROJECT INSTRUCTIONS

Click "Set project instructions" in your new project.

Copy the entire contents of CLAUDE_WEB_INSTRUCTIONS.md (from your download) and paste it into the instructions field.

Click Save.

STEP 2: START YOUR SESSION

In the chat, type:

    [My Website Project] CONTINUE

Claude will respond with an AIXORD status report:
- Current mode (DECISION)
- Active scope (None)
- Session state

This confirms AIXORD is active.

STEP 3: CREATE YOUR FIRST SCOPE

Type:

    SCOPE: Homepage

Claude will create a new SCOPE file structure and ask about:
- Objective
- Requirements
- Constraints

Answer the questions. Claude accumulates your decisions into the SCOPE.

STEP 4: APPROVE AND EXECUTE

When the SCOPE looks complete, type:

    APPROVED

Then:

    ENTER EXECUTION MODE

Claude shifts from planning to implementation. It will now:
- Execute against your approved SCOPE
- Track progress
- Flag blockers

STEP 5: AUDIT YOUR WORK

When execution feels complete, type:

    ENTER AUDIT MODE

Claude will review what was done against what was planned, identifying:
- Completed requirements
- Gaps or deviations
- Recommendations

STEP 6: END SESSION

To pause work cleanly, type:

    HALT

Claude will summarize the session and prepare a continuation point for next time.

WHAT YOU ACCOMPLISHED

You just ran a complete AIXORD cycle:
- DECISION: Defined what to build
- EXECUTION: Built it
- AUDIT: Verified it

Your project now has documented governance. Next session, type [PROJECT] CONTINUE and pick up exactly where you left off.""",

        "FIRST_SESSION_CHATGPT": """YOUR FIRST CHATGPT SESSION

This chapter walks you through running AIXORD with ChatGPT.

PREPARATION

Option A â€” Custom Instructions:
1. Go to Settings â†’ Personalization â†’ Custom Instructions
2. Paste the AIXORD template into "How would you like ChatGPT to respond?"

Option B â€” Create a Custom GPT:
1. Go to "Explore GPTs" â†’ "Create"
2. Paste the AIXORD template into the Instructions field
3. Name it "AIXORD Assistant"

STEP 1: START YOUR SESSION

In a new chat (or your Custom GPT), type:

    [PROJECT] CONTINUE

ChatGPT will respond with an AIXORD status report, confirming governance is active.

STEP 2: ENTER DECISION MODE

Type:

    ENTER DECISION MODE

ChatGPT shifts to planning mode. Describe what you want to accomplish:

    I want to write a blog post about productivity tips for remote workers.

ChatGPT will help you structure:
- Key points to cover
- Target audience
- Desired length and tone

STEP 3: APPROVE AND EXECUTE

When planning is complete, type:

    APPROVED
    ENTER EXECUTION MODE

ChatGPT will now draft the actual blog post based on your approved decisions.

STEP 4: REVIEW AND AUDIT

When the draft is complete, type:

    ENTER AUDIT MODE

ChatGPT will compare the output against your original requirements:
- Did it cover all key points?
- Is the tone correct?
- What's missing?

STEP 5: ITERATE OR COMPLETE

If changes are needed:

    Return to EXECUTION: Fix the introduction

If satisfied:

    HALT

ChatGPT summarizes the session.

WHAT YOU ACCOMPLISHED

You used AIXORD to:
- Plan before writing
- Execute against a plan
- Audit the result

No more rambling AI responses. Structured input â†’ structured output.""",

        "FIRST_SESSION_GEMINI": """YOUR FIRST GEMINI SESSION

This chapter walks you through running AIXORD with Google Gemini.

PREPARATION

Option A â€” Using Gems:
1. Go to gemini.google.com
2. Click "Gem manager" â†’ "New Gem"
3. Paste the AIXORD template into the instructions
4. Name it "AIXORD Governance"
5. Save

Option B â€” Direct Paste:
1. Start a new Gemini conversation
2. Paste the AIXORD template as your first message
3. Gemini will acknowledge governance mode

STEP 1: START YOUR SESSION

Type:

    [PROJECT] CONTINUE

Gemini responds with AIXORD status, confirming active governance.

STEP 2: DEFINE YOUR TASK

Type:

    ENTER DECISION MODE

    I need to create a presentation about our Q1 sales results.

Gemini helps you plan:
- Slide structure
- Key metrics to highlight
- Visual recommendations

STEP 3: APPROVE AND EXECUTE

Type:

    APPROVED
    ENTER EXECUTION MODE

Gemini generates the presentation content based on your approved structure.

STEP 4: AUDIT

Type:

    ENTER AUDIT MODE

Gemini reviews:
- Are all planned slides present?
- Do metrics match requirements?
- Is messaging consistent?

STEP 5: EXPORT TO GOOGLE DOCS

Once satisfied, ask Gemini to format for Google Slides export. Copy the content into your presentation.

Type:

    HALT

Session complete.

WHAT YOU ACCOMPLISHED

You governed an AI-assisted presentation creation:
- Planned structure before content
- Executed against the plan
- Audited for completeness

Gemini + AIXORD = reliable outputs.""",

        "FIRST_SESSION_COPILOT": """YOUR FIRST COPILOT SESSION

This chapter walks you through running AIXORD with GitHub Copilot.

PREPARATION

1. Open VS Code with Copilot enabled
2. Create or open a project folder
3. Create a file: .github/AIXORD.md
4. Paste the AIXORD template into this file

Copilot will reference this file for context.

STEP 1: START YOUR SESSION

Open Copilot Chat (Ctrl+Shift+I or Cmd+Shift+I) and type:

    @workspace [PROJECT] CONTINUE

Copilot acknowledges AIXORD governance and reports status.

STEP 2: CREATE A SCOPE

Type:

    SCOPE: AddUserAuth

Describe what you want:

    Add user authentication using JWT tokens. Users should be able to register, login, and logout.

Copilot helps structure requirements.

STEP 3: APPROVE AND EXECUTE

Type:

    APPROVED
    ENTER EXECUTION MODE

Copilot begins generating code:
- Auth middleware
- Login/register routes
- JWT utilities

Review each suggestion before accepting.

STEP 4: AUDIT

Type:

    ENTER AUDIT MODE

Copilot reviews:
- Are all auth requirements implemented?
- Are there security gaps?
- What tests are needed?

STEP 5: COMMIT

When satisfied, commit your changes with a meaningful message:

    git commit -m "feat: Add JWT authentication (SCOPE: AddUserAuth)"

Type:

    HALT

Session complete.

WHAT YOU ACCOMPLISHED

You governed AI-assisted coding:
- Defined requirements before coding
- Reviewed every suggestion
- Audited completeness

Copilot + AIXORD = reliable software.""",

        "FIRST_SESSION_BUILDER": """YOUR FIRST BUILDER SESSION

This chapter walks you through customizing AIXORD templates for your specific workflow.

THE SCENARIO

You're a freelance consultant. You want to:
- Use AIXORD with multiple clients
- Customize templates per client
- Maintain consistency across projects

STEP 1: CHOOSE YOUR BASE TEMPLATE

From the templates/ folder, select:
- AIXORD_UNIVERSAL.md for general use
- Platform-specific variants for dedicated workflows

Copy your chosen template to a new file:

    CLIENT_ACME_AIXORD.md

STEP 2: CUSTOMIZE THE HEADER

Edit the top section:

    ## Project: ACME Corp Website Redesign
    ## Client: ACME Corporation
    ## Director: [Your Name]
    ## Started: 2025-01-15

STEP 3: ADD CLIENT-SPECIFIC RULES

In the governance section, add rules:

    ### Client-Specific Rules
    - All deliverables require client approval before EXECUTION
    - Use ACME brand colors (#FF5733, #333333)
    - Weekly status reports required

STEP 4: CREATE SCOPE TEMPLATES

For repeatable work, create SCOPE templates:

    SCOPE_TEMPLATE_LANDING_PAGE.md
    SCOPE_TEMPLATE_EMAIL_CAMPAIGN.md
    SCOPE_TEMPLATE_BLOG_POST.md

Each template pre-fills common requirements.

STEP 5: TEST YOUR CUSTOMIZATION

Start a session with your customized template:

    [ACME Website] CONTINUE

Verify the AI acknowledges your custom rules.

WHAT YOU ACCOMPLISHED

You now have:
- Client-specific AIXORD configuration
- Reusable SCOPE templates
- Consistent governance across projects

Scale AIXORD to your business.""",

        "FIRST_SESSION_COMPLETE": """YOUR FIRST AIXORD SESSION

This chapter provides a universal walkthrough that works with any AI platform.

THE UNIVERSAL WORKFLOW

Regardless of platform (Claude, ChatGPT, Gemini, Copilot), the AIXORD cycle is:

    DECISION â†’ EXECUTION â†’ AUDIT

Let's walk through each phase.

PHASE 1: DECISION

Start your session:

    [PROJECT] CONTINUE

Enter decision mode:

    ENTER DECISION MODE

Describe your goal:

    I want to create a weekly meal planning system.

The AI helps you define:
- What "done" looks like
- Constraints and boundaries
- Required components

When planning is complete:

    APPROVED

PHASE 2: EXECUTION

Shift to building:

    ENTER EXECUTION MODE

The AI executes against your approved decisions:
- Generates content
- Creates structures
- Implements requirements

Important: The AI is now FROZEN to your approved scope. It cannot add features or change direction without returning to DECISION mode.

PHASE 3: AUDIT

Verify the work:

    ENTER AUDIT MODE

The AI compares output to plan:
- What was completed?
- What's missing?
- What deviated?

You decide: Accept, revise, or continue.

ENDING THE SESSION

When finished:

    HALT

The AI summarizes:
- What was accomplished
- Current state
- Continuation point

Next session, type [PROJECT] CONTINUE to resume exactly where you left off.

THE POWER OF GOVERNANCE

Without AIXORD:
- AI rambles and changes direction
- Context is lost between sessions
- No accountability for decisions

With AIXORD:
- Clear phases with explicit transitions
- Decisions are documented and frozen
- Progress is trackable and auditable

You are the Director. The AI serves your vision."""
    }

    config = MANUSCRIPTS.get(manuscript_name, {})
    chapter_key = config.get("session_chapter")
    if chapter_key:
        return chapters.get(chapter_key, "")
    return ""


def get_download_appendix(manuscript_name):
    """Generate the Download Instructions appendix for a manuscript."""
    config = MANUSCRIPTS.get(manuscript_name, {})

    return f"""APPENDIX: DOWNLOAD YOUR TEMPLATES

This book includes downloadable AIXORD templates and resources.

HOW TO DOWNLOAD

1. Visit: {config.get('gumroad_url', 'https://meritwise0.gumroad.com')}

2. Use discount code: {config.get('discount_code', 'N/A')} for your exclusive reader discount

3. Complete checkout and download the ZIP package

4. Extract the ZIP to a folder on your computer

WHAT'S INCLUDED

Your download contains:

â€¢ README.md â€” Getting started guide
â€¢ DISCLAIMER.md â€” Terms of use
â€¢ quick-start/
  â€¢ CHEAT_SHEET.md â€” Print-ready command reference
  â€¢ COMMAND_CARD.md â€” Complete command guide
  â€¢ CLAUDE_WEB_INSTRUCTIONS.md â€” Project setup
â€¢ templates/ â€” AIXORD templates
â€¢ examples/ â€” Sample sessions
â€¢ variants/ â€” Platform-specific variants

QUICK START

1. Read CHEAT_SHEET.md (2 minutes)
2. Copy CLAUDE_WEB_INSTRUCTIONS.md into your AI project settings
3. Start with: [PROJECT] CONTINUE

YOUR ACCESS CODE

Product: {config.get('product_name', 'AIXORD')}
Regular Price: {config.get('price', 'N/A')}
Your Price: FREE (with code)
Code: {config.get('discount_code', 'N/A')}

SUPPORT

Questions? Contact: support@pmerit.com

Â© 2025 PMERIT LLC"""


def add_page_break(doc, paragraph):
    """Add a page break before a paragraph."""
    run = paragraph.insert_paragraph_before()
    run.add_run().add_break(docx.enum.text.WD_BREAK.PAGE)


def find_paragraph_containing(doc, text):
    """Find index of paragraph containing text."""
    for i, para in enumerate(doc.paragraphs):
        if text.lower() in para.text.lower():
            return i
    return -1


def update_manuscripts():
    """Tasks 3-6: Update all manuscripts."""
    print("\n" + "=" * 60)
    print("TASKS 3-6: Update Manuscripts")
    print("=" * 60)

    for name, config in MANUSCRIPTS.items():
        docx_path = os.path.join(DIST_PATH, f"{name}.docx")
        if not os.path.exists(docx_path):
            print(f"  SKIP: {name}.docx not found")
            continue

        print(f"\n  Processing: {name}")

        # Backup
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = os.path.join(ARCHIVE_PATH, f"{name}_consolidation_backup_{timestamp}.docx")
        shutil.copy2(docx_path, backup_path)
        print(f"    Backed up âœ“")

        doc = Document(docx_path)
        full_text = "\n".join([p.text for p in doc.paragraphs])

        # Check what's already present
        has_disclaimer = "TERMS OF USE AND DISCLAIMER" in full_text or "NO WARRANTY" in full_text
        has_first_session = "Your First" in full_text and "Session" in full_text
        has_download = "DOWNLOAD YOUR TEMPLATES" in full_text or "HOW TO DOWNLOAD" in full_text
        has_discount = config.get("discount_code", "") in full_text

        print(f"    Has DISCLAIMER: {'âœ“' if has_disclaimer else 'âœ—'}")
        print(f"    Has First Session: {'âœ“' if has_first_session else 'âœ—'}")
        print(f"    Has Download Appendix: {'âœ“' if has_download else 'âœ—'}")
        print(f"    Has Discount Code: {'âœ“' if has_discount else 'âœ—'}")

        modified = False

        # Add First Session chapter if needed and not STARTER
        if config.get("session_chapter") and not has_first_session:
            print(f"    Adding First Session chapter...")
            chapter_content = get_first_session_content(name)
            if chapter_content:
                # Find insertion point (before Quick Reference or Appendix A)
                insert_idx = find_paragraph_containing(doc, "Quick Reference")
                if insert_idx == -1:
                    insert_idx = find_paragraph_containing(doc, "Appendix A")
                if insert_idx == -1:
                    insert_idx = find_paragraph_containing(doc, "Glossary")

                if insert_idx > 0:
                    # Insert chapter content
                    lines = chapter_content.strip().split('\n')
                    for line in reversed(lines):
                        line = line.strip()
                        if line:
                            new_para = doc.paragraphs[insert_idx].insert_paragraph_before(line)
                            # Style title
                            if line.startswith("YOUR FIRST"):
                                for run in new_para.runs:
                                    run.bold = True
                                    run.font.size = Pt(16)
                            elif line.startswith("STEP ") or line.startswith("PHASE ") or line.startswith("THE ") or line.startswith("WHAT YOU"):
                                for run in new_para.runs:
                                    run.bold = True
                    modified = True
                    print(f"      Added âœ“")

        # Add Download Appendix if not present
        if not has_download:
            print(f"    Adding Download Appendix...")
            appendix_content = get_download_appendix(name)

            # Find insertion point (before About the Author or at end)
            insert_idx = find_paragraph_containing(doc, "About the Author")
            if insert_idx == -1:
                insert_idx = len(doc.paragraphs) - 1

            if insert_idx > 0:
                lines = appendix_content.strip().split('\n')
                for line in reversed(lines):
                    line = line.strip()
                    if line:
                        new_para = doc.paragraphs[insert_idx].insert_paragraph_before(line)
                        if line.startswith("APPENDIX"):
                            for run in new_para.runs:
                                run.bold = True
                                run.font.size = Pt(16)
                        elif line.startswith("HOW TO") or line.startswith("WHAT'S") or line.startswith("QUICK START") or line.startswith("YOUR ACCESS") or line.startswith("SUPPORT"):
                            for run in new_para.runs:
                                run.bold = True
                modified = True
                print(f"      Added âœ“")

        if modified:
            doc.save(docx_path)
            print(f"    Saved âœ“")
        else:
            print(f"    No changes needed")

    return True


def final_verification():
    """Final verification of all deliverables."""
    print("\n" + "=" * 60)
    print("FINAL VERIFICATION")
    print("=" * 60)

    all_pass = True

    # Verify ZIPs
    print("\nZIP Packages:")
    for zip_name in PACKAGES.keys():
        zip_path = os.path.join(DIST_PATH, zip_name)
        if not os.path.exists(zip_path):
            print(f"  {zip_name}: NOT FOUND âœ—")
            all_pass = False
            continue

        with zipfile.ZipFile(zip_path, 'r') as zf:
            names = zf.namelist()

        checks = {
            "DISCLAIMER.md": "DISCLAIMER.md" in names,
            "templates/": any("templates/" in n for n in names),
            "examples/": any("examples/" in n for n in names),
            "variants/": any("variants/" in n for n in names),
        }

        passed = all(checks.values())
        status = "âœ“" if passed else "âœ—"
        print(f"  {zip_name}: {status}")
        if not passed:
            all_pass = False
            for check, result in checks.items():
                if not result:
                    print(f"    Missing: {check}")

    # Verify Manuscripts
    print("\nManuscripts:")
    for name, config in MANUSCRIPTS.items():
        docx_path = os.path.join(DIST_PATH, f"{name}.docx")
        if not os.path.exists(docx_path):
            print(f"  {name}: NOT FOUND âœ—")
            all_pass = False
            continue

        doc = Document(docx_path)
        full_text = "\n".join([p.text for p in doc.paragraphs])

        checks = {
            "DISCLAIMER": "NO WARRANTY" in full_text or "TERMS OF USE" in full_text,
            "First Session": config.get("session_chapter") is None or "Your First" in full_text,
            "Download Appendix": "DOWNLOAD YOUR TEMPLATES" in full_text or "HOW TO DOWNLOAD" in full_text,
            "Discount Code": config.get("discount_code", "") in full_text,
        }

        passed = all(checks.values())
        status = "âœ“" if passed else "âœ—"
        print(f"  {name}: {status}")
        if not passed:
            all_pass = False
            for check, result in checks.items():
                if not result:
                    print(f"    Missing: {check}")

    print("\n" + "=" * 60)
    if all_pass:
        print("ALL VERIFICATIONS PASSED! âœ“")
    else:
        print("SOME VERIFICATIONS FAILED - Review required")
    print("=" * 60)

    return all_pass


def main():
    print("=" * 60)
    print("AIXORD FINAL CONSOLIDATION SCRIPT")
    print("HANDOFF_FINAL_CONSOLIDATION_V1")
    print("=" * 60)

    # Create directories
    os.makedirs(ARCHIVE_PATH, exist_ok=True)
    os.makedirs(TEMP_PATH, exist_ok=True)
    os.makedirs(STAGING_PATH, exist_ok=True)

    # Execute tasks
    verify_and_add_disclaimer_to_zips()
    normalize_zip_folder_structure()
    update_manuscripts()

    # Cleanup
    if os.path.exists(TEMP_PATH):
        shutil.rmtree(TEMP_PATH)

    # Final verification
    final_verification()

    print("\n" + "=" * 60)
    print("CONSOLIDATION COMPLETE")
    print("=" * 60)
    print("\nNext Steps for Director:")
    print("1. Review manuscripts in Word for formatting")
    print("2. Prepare NDA for testers")
    print("3. Package for Nigerian testers")
    print("4. Distribute after NDA signed")


if __name__ == "__main__":
    main()

