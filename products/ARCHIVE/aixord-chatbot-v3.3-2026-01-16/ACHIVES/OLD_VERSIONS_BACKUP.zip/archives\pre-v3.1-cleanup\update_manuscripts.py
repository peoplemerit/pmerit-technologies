#!/usr/bin/env python3
"""
AIXORD Manuscript Update Script
Adds DISCLAIMER chapter and 'Your First AIXORD Session' to manuscripts
"""

import os
import shutil
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE

DIST_PATH = r"C:\dev\pmerit\Pmerit_Product_Development\products\aixord-chatbot\distribution"
STAGING_PATH = os.path.join(DIST_PATH, "staging")
ARCHIVE_PATH = os.path.join(DIST_PATH, "archives")

# Manuscript configurations
MANUSCRIPTS = {
    "MANUSCRIPT_STARTER": {
        "needs_first_session": False,
        "first_session_file": None,
    },
    "MANUSCRIPT_GENESIS": {
        "needs_first_session": True,
        "first_session_file": "FIRST_SESSION_GENESIS.txt",
    },
    "MANUSCRIPT_CLAUDE": {
        "needs_first_session": True,
        "first_session_file": "FIRST_SESSION_CLAUDE.txt",
    },
    "MANUSCRIPT_CHATGPT": {
        "needs_first_session": True,
        "first_session_file": "FIRST_SESSION_CHATGPT.txt",
    },
    "MANUSCRIPT_GEMINI": {
        "needs_first_session": True,
        "first_session_file": "FIRST_SESSION_GEMINI.txt",
    },
    "MANUSCRIPT_COPILOT": {
        "needs_first_session": True,
        "first_session_file": "FIRST_SESSION_COPILOT.txt",
    },
    "MANUSCRIPT_BUILDER": {
        "needs_first_session": True,
        "first_session_file": "FIRST_SESSION_BUILDER.txt",
    },
    "MANUSCRIPT_COMPLETE": {
        "needs_first_session": True,
        "first_session_file": "FIRST_SESSION_COMPLETE.txt",
    },
}

# Condensed disclaimer for manuscripts
DISCLAIMER_CONTENT = """TERMS OF USE AND DISCLAIMER

By using this book and the AIXORD methodology, you agree to the following terms:

NO WARRANTY: AIXORD products are provided "AS IS" without warranty of any kind.

NO GUARANTEE OF RESULTS: Your results depend on your implementation, project requirements, and the AI platforms you use.

NOT PROFESSIONAL ADVICE: AIXORD is not a substitute for legal, financial, medical, or other professional advice.

USER RESPONSIBILITY: You are solely responsible for reviewing AI outputs and making final decisions. The "Director" role explicitly places decision-making authority with you.

PROHIBITED USES: You may not use AIXORD to generate harmful content, engage in fraud, create malware, reverse-engineer for resale, or violate AI platform terms of service.

LIMITATION OF LIABILITY: PMERIT LLC is not liable for any damages exceeding the amount you paid for this product.

DISPUTE RESOLUTION: Disputes are resolved by binding arbitration in Maine. You waive your right to participate in class actions.

INTELLECTUAL PROPERTY: AIXORD methodology remains the property of PMERIT LLC. You receive a non-exclusive, non-transferable license for personal and organizational use.

Full terms available at: https://pmerit.com/aixord-terms

Contact: legal@pmerit.com | support@pmerit.com

© 2025 PMERIT LLC. All Rights Reserved."""


def find_paragraph_index(doc, search_text):
    """Find the index of a paragraph containing specific text."""
    for i, para in enumerate(doc.paragraphs):
        if search_text.lower() in para.text.lower():
            return i
    return -1


def insert_paragraph_after(doc, index, text, style=None):
    """Insert a new paragraph after the specified index."""
    # Get the paragraph at the index
    para = doc.paragraphs[index]
    # Create new paragraph element
    new_para = doc.add_paragraph(text, style)
    # Move it after the target paragraph
    para._p.addnext(new_para._p)
    return new_para


def add_disclaimer_chapter(doc):
    """Add DISCLAIMER chapter after Copyright, before Table of Contents."""
    print("  Adding DISCLAIMER chapter...")

    # Find the Table of Contents
    toc_index = find_paragraph_index(doc, "Table of Contents")
    if toc_index == -1:
        toc_index = find_paragraph_index(doc, "Contents")

    if toc_index == -1:
        print("    WARNING: Could not find Table of Contents")
        return False

    # Find a position after Copyright (usually 2-3 paragraphs before TOC)
    # We'll insert right before TOC
    insert_index = toc_index - 1

    # Insert disclaimer content (in reverse order since we insert after same position)
    lines = DISCLAIMER_CONTENT.strip().split('\n')

    # First add a page break paragraph before the disclaimer
    for i, line in enumerate(reversed(lines)):
        line = line.strip()
        if line:
            para = doc.paragraphs[insert_index]
            new_para = para.insert_paragraph_before(line)
            if i == len(lines) - 1:  # First line (title)
                new_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
                for run in new_para.runs:
                    run.bold = True
                    run.font.size = Pt(14)

    print("    DISCLAIMER added before Table of Contents")
    return True


def add_first_session_chapter(doc, content_file):
    """Add 'Your First AIXORD Session' chapter."""
    print(f"  Adding First Session chapter from {content_file}...")

    content_path = os.path.join(STAGING_PATH, content_file)
    if not os.path.exists(content_path):
        print(f"    ERROR: Content file not found: {content_path}")
        return False

    with open(content_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # Find Quick Reference or Glossary (chapters near the end)
    quick_ref_index = find_paragraph_index(doc, "Quick Reference")
    if quick_ref_index == -1:
        quick_ref_index = find_paragraph_index(doc, "Appendix A")

    if quick_ref_index == -1:
        print("    WARNING: Could not find insertion point")
        return False

    # Insert before Quick Reference
    insert_index = quick_ref_index - 1

    lines = content.strip().split('\n')

    for i, line in enumerate(reversed(lines)):
        line = line.strip()
        if line:
            para = doc.paragraphs[insert_index]
            new_para = para.insert_paragraph_before(line)

            # Style the chapter title
            if line.startswith("Chapter:") or line.startswith("Your First"):
                new_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
                for run in new_para.runs:
                    run.bold = True
                    run.font.size = Pt(16)
            # Style step headers
            elif line.startswith("Step "):
                for run in new_para.runs:
                    run.bold = True

    print("    First Session chapter added")
    return True


def process_manuscript(name, config):
    """Process a single manuscript."""
    docx_path = os.path.join(DIST_PATH, f"{name}.docx")

    if not os.path.exists(docx_path):
        print(f"SKIP: {name}.docx not found")
        return False

    print(f"\nProcessing: {name}")

    # Backup original
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = os.path.join(ARCHIVE_PATH, f"{name}_backup_{timestamp}.docx")
    shutil.copy2(docx_path, backup_path)
    print(f"  Backed up to: {os.path.basename(backup_path)}")

    # Open document
    doc = Document(docx_path)

    # Add DISCLAIMER
    add_disclaimer_chapter(doc)

    # Add First Session chapter if needed
    if config["needs_first_session"] and config["first_session_file"]:
        add_first_session_chapter(doc, config["first_session_file"])

    # Save document
    doc.save(docx_path)
    print(f"  Saved: {name}.docx")

    return True


def main():
    print("=" * 50)
    print("AIXORD Manuscript Update Script")
    print("=" * 50)

    # Ensure directories exist
    os.makedirs(ARCHIVE_PATH, exist_ok=True)

    success_count = 0
    for name, config in MANUSCRIPTS.items():
        try:
            if process_manuscript(name, config):
                success_count += 1
        except Exception as e:
            print(f"  ERROR: {str(e)}")

    print("\n" + "=" * 50)
    print(f"Completed: {success_count}/{len(MANUSCRIPTS)} manuscripts updated")
    print("=" * 50)


if __name__ == "__main__":
    main()
