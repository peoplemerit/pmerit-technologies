# AIXORD Starter Pack

**Version:** 3.2.1 | **Updated:** January 2026

---

## What is AIXORD?

AIXORD (AI Execution Order) transforms chaotic AI conversations into structured, productive projects. You stay in control as the Director while your AI serves as your intelligent Architect.

**Starter Pack** includes free tier guides for Claude, ChatGPT, and Gemini users.

---

## Quick Start (5 Minutes)

### Step 1: Choose Your AI Platform

| Platform | Free Tier Guide |
|----------|-----------------|
| Claude | `AIXORD_CLAUDE_FREE.md` |
| ChatGPT | `AIXORD_CHATGPT_FREE.md` |
| Gemini | `AIXORD_GEMINI_FREE.md` |

### Step 2: Setup (All Platforms)

1. Open your AI chat
2. Copy the ENTIRE contents of `AIXORD_GOVERNANCE_UNIVERSAL_V3.2.1.md`
3. Paste it at the START of your conversation
4. Type: `PMERIT CONTINUE`
5. At session end, ask for `HANDOFF` and save it locally
6. Next session: paste governance + handoff to continue

### Step 3: Tell Your AI What You Need

- **Have a project idea?** -> "I want to build [description]"
- **No idea yet?** -> "I don't know what to build, help me discover"
- **Have a plan already?** -> "I have a plan, help me implement it"

That's it. AIXORD guides you from there.

---

## What's In This Package

| File | What It Is | What To Do |
|------|------------|------------|
| `AIXORD_GOVERNANCE_UNIVERSAL_V3.2.1.md` | Universal governance | Paste into your AI |
| `AIXORD_STATE_UNIVERSAL_V3.2.1.json` | State tracking template | Save locally |
| `PURPOSE_BOUND_OPERATION_SPEC.md` | Focus enforcement spec | Reference document |
| `AIXORD_CLAUDE_FREE.md` | Claude free tier guide | Read first |
| `AIXORD_CHATGPT_FREE.md` | ChatGPT free tier guide | Read first |
| `AIXORD_GEMINI_FREE.md` | Gemini free tier guide | Read first |
| `DISCLAIMER.md` | Legal disclaimer | Keep for reference |
| `LICENSE.md` | License terms | Read before using |
| `LICENSE_KEY.txt` | Your license certificate | Keep for records |

---

## Key Terms (For Non-Technical Users)

| Term | Meaning |
|------|---------|
| **README** | "Read Me" -- this file. Always read first. |
| **.md files** | Markdown files -- plain text you can open in any text editor |
| **.json files** | Data files -- store structured information |
| **ZIP file** | Compressed folder -- extract before using |
| **Extract** | Unpack the ZIP (Windows: Right-click -> Extract All) |

---

## Need Help?

- **Email:** support@pmerit.com
- **Updates:** Visit pmerit.com/aixord
- **Full Documentation:** See the AIXORD book you purchased

---

*AIXORD v3.2.1 -- Purpose-Bound. Disciplined. Focused.*
*Copyright 2026 PMERIT LLC. All Rights Reserved.*
