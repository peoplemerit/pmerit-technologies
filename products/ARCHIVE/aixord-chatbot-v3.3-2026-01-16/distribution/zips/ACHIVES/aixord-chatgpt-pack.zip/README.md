# AIXORD ChatGPT Pack

**Version:** 3.2.1 | **Updated:** January 2026

---

## What is AIXORD?

AIXORD (AI Execution Order) transforms chaotic AI conversations into structured, productive projects. You stay in control as the Director while your AI serves as your intelligent Architect.

**ChatGPT Pack** is optimized specifically for ChatGPT users -- Free, Plus, and Pro tiers.

**NEW in v3.2.1:** Purpose-Bound Operation keeps AI focused exclusively on YOUR project objective.

---

## Quick Start (5 Minutes)

### Step 1: Know Your Setup

| If You Have... | Your Tier | Setup Method |
|----------------|-----------|--------------|
| ChatGPT Pro (with GPTs) | Tier A | Custom GPT |
| ChatGPT Plus | Tier B | Guided manual |
| ChatGPT Free | Tier C | Fully manual |

### Step 2: Setup by Tier

**TIER A (Pro with GPTs):**
1. Create a Custom GPT at chat.openai.com
2. Paste the ENTIRE contents of `AIXORD_GOVERNANCE_CHATGPT_GPT.md` in the Instructions
3. Upload `AIXORD_STATE_CHATGPT_V3.2.1.json` to Knowledge
4. Start a conversation and type: `PMERIT CONTINUE`

**TIER B (Plus):**
1. Open ChatGPT at chat.openai.com
2. Paste the ENTIRE contents of `AIXORD_GOVERNANCE_CHATGPT_V3.2.1.md` at conversation start
3. Type: `PMERIT CONTINUE`
4. ChatGPT will guide you through implementation steps

**TIER C (Free):**
1. Open ChatGPT at chat.openai.com
2. Copy the ENTIRE contents of `AIXORD_GOVERNANCE_CHATGPT_V3.2.1.md`
3. Paste it at the START of your conversation
4. Type: `PMERIT CONTINUE`
5. At session end, ask for `HANDOFF` and save it locally
6. Next session: paste governance + handoff to continue

### Step 3: Tell ChatGPT What You Need

- **Have a project idea?** -> "I want to build [description]"
- **No idea yet?** -> "I don't know what to build, help me discover"
- **Have a plan already?** -> "I have a plan, help me implement it"

That's it. AIXORD guides you from there.

---

## What's In This Package

| File | What It Is | What To Do |
|------|------------|------------|
| `AIXORD_GOVERNANCE_CHATGPT_V3.2.1.md` | Full governance | Paste into ChatGPT |
| `AIXORD_GOVERNANCE_CHATGPT_GPT.md` | **Condensed for GPTs** | Paste into GPT Instructions |
| `AIXORD_STATE_CHATGPT_V3.2.1.json` | State tracking template | Upload to GPT Knowledge |
| `AIXORD_PHASE_DETAILS.md` | Detailed phase behaviors | Upload to GPT Knowledge |
| `PURPOSE_BOUND_OPERATION_SPEC.md` | Focus enforcement spec | Reference document |
| `AIXORD_CHATGPT_PRO.md` | Pro tier guide | Read first |
| `AIXORD_CHATGPT_PLUS.md` | Plus tier guide | Read first |
| `AIXORD_CHATGPT_FREE.md` | Free tier guide | Read first |
| `DISCLAIMER.md` | Legal disclaimer | Keep for reference |
| `LICENSE.md` | License terms | Read before using |
| `LICENSE_KEY.txt` | Your license certificate | Keep for records |

### File Loading Order

1. **AIXORD_GOVERNANCE_CHATGPT_V3.2.1.md** -- Core rules (REQUIRED)
2. **AIXORD_STATE_CHATGPT_V3.2.1.json** -- Session state (REQUIRED)
3. **AIXORD_PHASE_DETAILS.md** -- Phase behaviors (OPTIONAL)
4. **AIXORD_CHATGPT_*.md** -- Choose your tier guide (OPTIONAL)
5. **PURPOSE_BOUND_OPERATION_SPEC.md** -- Reference only

---

## v3.2.1 New Features

| Feature | Description |
|---------|-------------|
| **Purpose-Bound Operation** | AI stays focused on YOUR project objective |
| **Behavioral Firewalls** | Eliminates unsolicited suggestions |
| **Reasoning Transparency** | See why AI makes recommendations |
| **User Audit Checklist** | 10-second compliance verification |

### New Commands

| Command | Effect |
|---------|--------|
| `PURPOSE-BOUND: STRICT` | Maximum focus, no tangents |
| `PURPOSE-BOUND: STANDARD` | Default with options |
| `PURPOSE-BOUND: RELAXED` | Brief tangents allowed |
| `EXPAND SCOPE: [topic]` | Add topic to project |
| `SHOW SCOPE` | Display current project scope |

---

## Key Terms (For Non-Technical Users)

| Term | Meaning |
|------|---------|
| **README** | "Read Me" -- this file. Always read first. |
| **.md files** | Markdown files -- plain text you can open in any text editor |
| **.json files** | Data files -- store structured information |
| **ZIP file** | Compressed folder -- extract before using |
| **Extract** | Unpack the ZIP (Windows: Right-click -> Extract All) |
| **Custom GPT** | ChatGPT Pro feature -- create specialized AI assistants |

---

## Need Help?

- **Email:** support@pmerit.com
- **Updates:** Visit pmerit.com/aixord
- **Full Documentation:** See the AIXORD book you purchased

---

*AIXORD v3.2.1 -- Purpose-Bound. Disciplined. Focused.*
*Copyright 2026 PMERIT LLC. All Rights Reserved.*
