# AIXORD Genesis

**Version:** 3.2.1 | **Updated:** January 2026

---

## What is AIXORD?

AIXORD (AI Execution Order) transforms chaotic AI conversations into structured, productive projects. You stay in control as the Director while your AI serves as your intelligent Architect.

**Genesis** is the idea-to-system variant -- designed to help you create projects from scratch using the SCOPE GENESIS protocol.

---

## Quick Start (5 Minutes)

### Step 1: Open Any AI Chat

Genesis works with any AI platform (Claude, ChatGPT, Gemini, etc.)

### Step 2: Start Genesis

1. Copy the ENTIRE contents of `AIXORD_GENESIS.md`
2. Paste it at the START of your conversation
3. Type: `PMERIT CONTINUE`
4. Follow the Genesis workflow

### Step 3: What Genesis Does

- Helps you discover and define project ideas
- Creates structured MASTER_SCOPE for your vision
- Breaks down into implementable SCOPEs
- Provides templates for consistent structure

---

## What's In This Package

| File | What It Is | What To Do |
|------|------------|------------|
| `AIXORD_GENESIS.md` | Genesis workflow | Paste into your AI |
| `AIXORD_STATE_GENESIS_V3.2.1.json` | State tracking template | Save locally |
| `PURPOSE_BOUND_OPERATION_SPEC.md` | Focus enforcement spec | Reference document |
| `MASTER_SCOPE_TEMPLATE.md` | Project vision template | Use for project overview |
| `SCOPE_TEMPLATE.md` | Feature scope template | Use for individual features |
| `HANDOFF_TEMPLATE.md` | Session handoff template | Use to save session state |
| `LICENSE.md` | License terms | Read before using |
| `LICENSE_KEY.txt` | Your license certificate | Keep for records |

---

## Genesis Workflow

1. **DISCOVER** - Explore ideas with AI guidance
2. **DEFINE** - Create MASTER_SCOPE vision document
3. **DECOMPOSE** - Break into implementable SCOPEs
4. **DOCUMENT** - Generate structured project files

---

## Key Terms

| Term | Meaning |
|------|---------|
| **README** | "Read Me" -- this file. Always read first. |
| **GENESIS** | Protocol for systematic project creation |
| **SCOPE** | A single implementable unit of work |
| **MASTER_SCOPE** | Project vision and overview document |
| **HANDOFF** | Session state save for continuity |

---

## Need Help?

- **Email:** support@pmerit.com
- **Updates:** Visit pmerit.com/aixord
- **Full Documentation:** See the AIXORD book you purchased

---

*AIXORD v3.2.1 -- Purpose-Bound. Disciplined. Focused.*
*Copyright 2026 PMERIT LLC. All Rights Reserved.*
